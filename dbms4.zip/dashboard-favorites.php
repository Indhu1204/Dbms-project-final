<?php
// Start session
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // User is not logged in, redirect to login page
    header("Location: login.php");
    exit();
}

// Database connection
$host = "localhost";
$dbname = "paws";
$username = "root"; // Change this to your database username
$password = "2424"; // Change this to your database password

// Process favorite action if requested (add or remove)
$message = "";
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && isset($_POST['animal_id'])) {
    $action = $_POST['action'];
    $animal_id = $_POST['animal_id'];
    $user_id = $_SESSION['user_id'];
    
    try {
        // Create a new PDO instance
        $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
        
        // Set the PDO error mode to exception
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        if ($action == "add") {
            // Check if already favorited
            $check_sql = "SELECT * FROM favorites WHERE user_id = :user_id AND animal_id = :animal_id";
            $check_stmt = $pdo->prepare($check_sql);
            $check_stmt->bindParam(":user_id", $user_id, PDO::PARAM_INT);
            $check_stmt->bindParam(":animal_id", $animal_id, PDO::PARAM_INT);
            $check_stmt->execute();
            
            if ($check_stmt->rowCount() == 0) {
                // Insert new favorite
                $insert_sql = "INSERT INTO favorites (user_id, animal_id, created_at) VALUES (:user_id, :animal_id, NOW())";
                $insert_stmt = $pdo->prepare($insert_sql);
                $insert_stmt->bindParam(":user_id", $user_id, PDO::PARAM_INT);
                $insert_stmt->bindParam(":animal_id", $animal_id, PDO::PARAM_INT);
                $insert_stmt->execute();
                $message = "Animal added to favorites successfully!";
            } else {
                $message = "This animal is already in your favorites.";
            }
        } elseif ($action == "remove") {
            // Remove from favorites
            $remove_sql = "DELETE FROM favorites WHERE user_id = :user_id AND animal_id = :animal_id";
            $remove_stmt = $pdo->prepare($remove_sql);
            $remove_stmt->bindParam(":user_id", $user_id, PDO::PARAM_INT);
            $remove_stmt->bindParam(":animal_id", $animal_id, PDO::PARAM_INT);
            $remove_stmt->execute();
            $message = "Animal removed from favorites successfully!";
        }
    } catch(PDOException $e) {
        $message = "Database error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Favorites - Paws & Hearts</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
    /* General Reset */
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background-color: #f5f6fa;
        color: #333;
    }
    a {
        text-decoration: none;
        color: inherit;
    }
    ul {
        list-style: none;
    }

    /* Header */
    header {
        background-color: #fff;
        border-bottom: 1px solid #ddd;
        padding: 1rem 0;
    }
    nav {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    .logo h1 {
        font-size: 1.5rem;
        color: #e67e22;
    }
    .nav-links {
        display: flex;
        gap: 1rem;
    }
    .nav-links li a {
        padding: 0.5rem 1rem;
        color: #555;
        font-weight: 500;
    }
    .nav-links li a.active,
    .nav-links li a:hover {
        color: #e67e22;
    }
    .btn {
        background-color: #e67e22;
        color: white;
        padding: 0.5rem 1rem;
        border-radius: 20px;
        font-weight: bold;
        border: none;
        cursor: pointer;
    }
    .btn:hover {
        background-color: #d35400;
    }
    .burger {
        display: none;
    }

    /* Container */
    .container {
        width: 90%;
        max-width: 1200px;
        margin: 0 auto;
    }

    /* Layout */
    .dashboard-container {
        display: flex;
        margin-top: 2rem;
        gap: 2rem;
    }
    .dashboard-sidebar {
        width: 250px;
        background-color: #fff;
        padding: 1rem;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0,0,0,0.05);
    }
    .dashboard-content {
        flex: 1;
    }

    /* Profile */
    .user-profile {
        text-align: center;
        margin-bottom: 2rem;
    }
    .profile-image img {
        width: 80px;
        height: 80px;
        border-radius: 50%;
    }
    .profile-info h3 {
        margin: 0.5rem 0 0.2rem;
    }
    .profile-info p {
        font-size: 0.9rem;
        color: #888;
    }

    /* Sidebar Navigation */
    .dashboard-menu ul li {
        margin: 0.7rem 0;
    }
    .dashboard-menu ul li a {
        display: flex;
        align-items: center;
        padding: 0.6rem;
        border-radius: 5px;
        color: #333;
        transition: background 0.3s;
    }
    .dashboard-menu ul li a i {
        margin-right: 0.6rem;
    }
    .dashboard-menu ul li a:hover,
    .dashboard-menu ul li.active a {
        background-color: #e67e22;
        color: white;
    }

    /* Dashboard Header */
    .dashboard-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 1.5rem;
    }
    .dashboard-header h2 {
        font-size: 1.5rem;
    }

    /* Alert Message */
    .alert {
        padding: 1rem;
        margin-bottom: 1.5rem;
        border-radius: 5px;
        background-color: #f8f9fa;
        border-left: 4px solid #e67e22;
    }
    .alert.success {
        background-color: #d4edda;
        border-left-color: #28a745;
        color: #155724;
    }
    .alert.error {
        background-color: #f8d7da;
        border-left-color: #dc3545;
        color: #721c24;
    }

    /* Favorites Grid */
    .favorites-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
        gap: 1.5rem;
    }
    .favorite-card {
        background-color: #fff;
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 0 10px rgba(0,0,0,0.05);
        transition: transform 0.3s ease;
    }
    .favorite-card:hover {
        transform: translateY(-5px);
    }
    .favorite-image {
        height: 180px;
        overflow: hidden;
        position: relative;
    }
    .favorite-image img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
    .favorite-heart {
        position: absolute;
        top: 10px;
        right: 10px;
        background-color: rgba(255, 255, 255, 0.9);
        width: 40px;
        height: 40px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.3s ease;
    }
    .favorite-heart i {
        color: #e74c3c;
        font-size: 1.2rem;
    }
    .favorite-heart:hover {
        background-color: #fff;
        box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }
    .favorite-info {
        padding: 1rem;
    }
    .favorite-info h3 {
        margin-bottom: 0.5rem;
        font-size: 1.2rem;
    }
    .favorite-meta {
        display: flex;
        justify-content: space-between;
        margin-bottom: 0.8rem;
        font-size: 0.9rem;
        color: #777;
    }
    .favorite-actions {
        display: flex;
        gap: 0.5rem;
    }
    .btn-sm {
        padding: 0.3rem 0.7rem;
        font-size: 0.85rem;
    }
    .empty-favorites {
        text-align: center;
        padding: 3rem;
        background-color: #fff;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0,0,0,0.05);
    }
    .empty-favorites i {
        font-size: 4rem;
        color: #ddd;
        margin-bottom: 1rem;
    }
    .empty-favorites h3 {
        margin-bottom: 1rem;
    }

    /* Footer */
    footer {
        margin-top: 3rem;
        background-color: #fff;
        padding: 1rem;
        text-align: center;
        font-size: 0.9rem;
        color: #999;
        border-top: 1px solid #ddd;
    }

    /* Responsive */
    @media (max-width: 992px) {
        .dashboard-container {
            flex-direction: column;
        }
        .dashboard-sidebar {
            width: 100%;
        }
    }
    @media (max-width: 768px) {
        .favorites-grid {
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
        }
        .nav-links {
            display: none;
        }
        .burger {
            display: block;
            cursor: pointer;
        }
    }
    @media (max-width: 480px) {
        .favorites-grid {
            grid-template-columns: 1fr;
        }
        .favorite-actions {
            flex-direction: column;
        }
    }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <nav>
                <div class="logo">
                    <h1><i class="fas fa-paw"></i> Paws & Hearts</h1>
                </div>
                <ul class="nav-links">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="animals.php">Animals</a></li>
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li><a href="contact.html">Contact</a></li>
                    <li><a href="#" id="logoutBtn" class="btn">Logout</a></li>
                </ul>
                <div class="burger">
                    <i class="fas fa-bars"></i>
                </div>
            </nav>
        </div>
    </header>

    <section class="dashboard">
        <div class="container">
            <div class="dashboard-container">
                <aside class="dashboard-sidebar">
                    <div class="user-profile">
                        <div class="profile-image">
                            <img src="https://images.unsplash.com/photo-1531123897727-8f129e1688ce?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80" alt="User profile">
                        </div>
                        <div class="profile-info">
                            <h3><?php echo $_SESSION['first_name'] . ' ' . $_SESSION['last_name']; ?></h3>
                            <p>Member since: <?php echo date('F Y', strtotime('-' . rand(1, 12) . ' months')); ?></p>
                        </div>
                    </div>
                    <nav class="dashboard-menu">
                        <ul>
                            <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                            <li><a href="dashboard-applications.php"><i class="fas fa-file-alt"></i> My Applications</a></li>
                            <li class="active"><a href="favorites.php"><i class="fas fa-heart"></i> Favorites</a></li>
                        </ul>
                    </nav>
                </aside>
                <main class="dashboard-content">
                    <div class="dashboard-header">
                        <h2>My Favorites</h2>
                        <div class="dashboard-actions">
                            <a href="animals.php" class="btn btn-primary"><i class="fas fa-paw"></i> Browse More Animals</a>
                        </div>
                    </div>
                    
                    <?php if (!empty($message)): ?>
                    <div class="alert <?php echo strpos($message, 'error') !== false ? 'error' : 'success'; ?>">
                        <?php echo $message; ?>
                    </div>
                    <?php endif; ?>
                    
                    <?php
                    try {
                        // Create a new PDO instance
                        $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
                        
                        // Set the PDO error mode to exception
                        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                        
                        // Get user's favorites with animal details
                        $sql = "SELECT a.*, f.created_at as favorited_at 
                                FROM favorites f 
                                JOIN animals a ON f.animal_id = a.id 
                                WHERE f.user_id = :user_id 
                                ORDER BY f.created_at DESC";
                        
                        $stmt = $pdo->prepare($sql);
                        $stmt->bindParam(":user_id", $_SESSION['user_id'], PDO::PARAM_INT);
                        $stmt->execute();
                        
                        $favorites = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    } catch(PDOException $e) {
                        echo "<div class='alert error'>Database error: " . $e->getMessage() . "</div>";
                        $favorites = [];
                    }
                    ?>
                    
                    <?php if (count($favorites) > 0): ?>
                    <div class="favorites-grid">
                        <?php foreach ($favorites as $animal): ?>
                        <div class="favorite-card">
                            <div class="favorite-image">
                                <img src="<?php echo !empty($animal['image_url']) ? $animal['image_url'] : 'https://images.unsplash.com/photo-1601758125946-6ec2ef64daf8?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80'; ?>" alt="<?php echo $animal['name']; ?>">
                                <form method="post" class="favorite-heart-form">
                                    <input type="hidden" name="animal_id" value="<?php echo $animal['id']; ?>">
                                    <input type="hidden" name="action" value="remove">
                                    <button type="submit" class="favorite-heart" title="Remove from favorites">
                                        <i class="fas fa-heart"></i>
                                    </button>
                                </form>
                            </div>
                            <div class="favorite-info">
                                <h3><?php echo $animal['name']; ?></h3>
                                <div class="favorite-meta">
                                    <span><i class="fas fa-paw"></i> <?php echo ucfirst($animal['species']); ?></span>
                                    <span><i class="fas fa-birthday-cake"></i> <?php echo $animal['age']; ?> years</span>
                                </div>
                                <p><?php echo substr($animal['description'], 0, 80) . '...'; ?></p>
                                <div class="favorite-actions">
                                    <a href="animal-details.php?id=<?php echo $animal['id']; ?>" class="btn btn-sm">View Details</a>
                                    <a href="apply.php?id=<?php echo $animal['id']; ?>" class="btn btn-sm">Apply to Adopt</a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php else: ?>
                    <div class="empty-favorites">
                        <i class="far fa-heart"></i>
                        <h3>No Favorites Yet</h3>
                        <p>You haven't added any animals to your favorites list.</p>
                        <a href="animals.php" class="btn">Find Animals to Love</a>
                    </div>
                    <?php endif; ?>
                </main>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <p>&copy; 2023 Paws & Hearts Animal Adoption. All rights reserved.</p>
        </div>
    </footer>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Toggle mobile navigation
        const burger = document.querySelector('.burger');
        const navLinks = document.querySelector('.nav-links');
        
        if (burger) {
            burger.addEventListener('click', function() {
                navLinks.style.display = navLinks.style.display === 'flex' ? 'none' : 'flex';
            });
        }
        
        // Logout functionality
        document.getElementById('logoutBtn').addEventListener('click', function(e) {
            e.preventDefault();
            // Create a form to post to logout.php
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = 'logout.php';
            document.body.appendChild(form);
            form.submit();
        });
    });
    </script>
</body>
</html>