<?php
// Database connection
$db_host = 'localhost';
$db_user = 'root';  // Change as per your MySQL credentials
$db_pass = '2424';      // Change as per your MySQL credentials
$db_name = 'paws';

// Create connection
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}