<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Paws & Hearts - Animal Adoption</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: Arial, sans-serif;
    }

    body {
        line-height: 1.6;
        background: #fefefe;
        color: #333;
    }

    a {
        text-decoration: none;
        color: inherit;
    }

    .container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 0 20px;
    }

    header {
        background: #ff6f61;
        padding: 15px 0;
    }

    nav {
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
    }

    .logo h1 {
        color: #fff;
        font-size: 1.8rem;
    }

    .nav-links {
        list-style: none;
        display: flex;
        gap: 20px;
    }

    .nav-links li a {
        color: #fff;
        font-weight: bold;
        padding: 8px 12px;
        border-radius: 5px;
    }

    .nav-links li a.active, .nav-links li a:hover {
        background: #fff;
        color: #ff6f61;
    }

    .btn {
        background: #fff;
        color: #ff6f61;
        padding: 8px 16px;
        border-radius: 5px;
        font-weight: bold;
    }

    .hero {
        background: url('https://images.unsplash.com/photo-1518717758536-85ae29035b6d') center/cover no-repeat;
        color: #fff;
        padding: 100px 0;
        text-align: center;
    }

    .hero h1 {
        font-size: 2.5rem;
        margin-bottom: 20px;
    }

    .hero p {
        font-size: 1.2rem;
        margin-bottom: 30px;
    }

    .hero-buttons a {
        margin: 0 10px;
    }

    .btn-primary {
        background: #fff;
        color: #ff6f61;
    }

    .btn-secondary {
        background: transparent;
        border: 2px solid #fff;
        color: #fff;
    }

    .how-it-works, .featured-animals, .about, .contact {
        padding: 60px 0;
        text-align: center;
    }

    .steps {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-around;
        margin-top: 40px;
    }

    .step {
        flex: 1 1 200px;
        padding: 20px;
    }

    .step-icon {
        font-size: 2rem;
        margin-bottom: 15px;
        color: #ff6f61;
    }

    .animals-grid {
        display: flex;
        flex-wrap: wrap;
        gap: 20px;
        justify-content: center;
        margin-top: 30px;
    }

    .about-content {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 40px;
        text-align: left;
    }

    .about-text {
        flex: 1;
    }

    .about-image img {
        width: 100%;
        max-width: 500px;
        border-radius: 10px;
    }

    .contact-container {
        display: flex;
        flex-wrap: wrap;
        gap: 40px;
        justify-content: space-between;
        text-align: left;
    }

    .contact-info {
        flex: 1;
    }

    .contact-form {
        flex: 1;
    }

    .form-group {
        margin-bottom: 15px;
    }

    .form-group input, .form-group textarea {
        width: 100%;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }

    footer {
        background: #333;
        color: #fff;
        padding-top: 40px;
    }

    .footer-content {
        display: flex;
        flex-wrap: wrap;
        gap: 40px;
        justify-content: space-between;
        padding-bottom: 20px;
    }

    .footer-section h3 {
        margin-bottom: 15px;
    }

    .footer-section ul {
        list-style: none;
    }

    .footer-section ul li {
        margin-bottom: 8px;
    }

    .footer-section ul li a {
        color: #fff;
        font-size: 0.9rem;
    }

    .newsletter-form {
        display: flex;
        gap: 10px;
        margin-top: 10px;
    }

    .newsletter-form input {
        flex: 1;
        padding: 8px;
        border: none;
        border-radius: 5px;
    }

    .newsletter-form button {
        padding: 8px 12px;
        background: #ff6f61;
        border: none;
        color: #fff;
        border-radius: 5px;
    }

    .footer-bottom {
        background: #222;
        text-align: center;
        padding: 10px 0;
        font-size: 0.9rem;
    }

    .social-links a {
        margin-right: 10px;
        color: #fff;
        font-size: 1.2rem;
    }

    .burger {
        display: none;
        font-size: 1.5rem;
        color: #fff;
        cursor: pointer;
    }

    @media (max-width: 768px) {
        .nav-links {
            display: none;
            flex-direction: column;
            background: #ff6f61;
            position: absolute;
            top: 70px;
            right: 20px;
            padding: 20px;
            border-radius: 8px;
        }

        .burger {
            display: block;
        }

        .about-content, .contact-container {
            flex-direction: column;
        }

        .steps {
            flex-direction: column;
            align-items: center;
        }
    }
</style>
</head>
<body>
    <header>
        <div class="container">
            <nav>
                <div class="logo">
                    <h1><i class="fas fa-paw"></i> Paws & Hearts</h1>
                </div>
                <ul class="nav-links">
                    <li><a href="home.php" class="active">Home</a></li>
                    <li><a href="animals.php">Animals</a></li>
                    <li><a href="about.html">About</a></li>
                    <li><a href="contact.html">Contact</a></li>
                    <li><a href="dashboard.php" class="btn">My Dashboard</a></li>
                </ul>
                <div class="burger">
                    <i class="fas fa-bars"></i>
                </div>
            </nav>
        </div>
    </header>

    <section class="hero">
        <div class="container">
            <div class="hero-content">
                <h1>Find Your Perfect Furry Friend</h1>
                <p>Thousands of animals are waiting for a loving home. Could you be their perfect match?</p>
                <div class="hero-buttons">
                    <a href="animals.php" class="btn btn-primary">Adopt Now</a>
                    <a href="#how-it-works" class="btn btn-secondary">How It Works</a>
                </div>
            </div>
        </div>
    </section>

    <section id="how-it-works" class="how-it-works">
        <div class="container">
            <h2>How Our Adoption Process Works</h2>
            <div class="steps">
                <div class="step">
                    <div class="step-icon"><i class="fas fa-search"></i></div>
                    <h3>1. Browse Animals</h3>
                    <p>View our available animals and find one that matches your lifestyle.</p>
                </div>
                <div class="step">
                    <div class="step-icon"><i class="fas fa-file-alt"></i></div>
                    <h3>2. Submit Application</h3>
                    <p>Fill out our adoption application form with your details.</p>
                </div>
                <div class="step">
                    <div class="step-icon"><i class="fas fa-home"></i></div>
                    <h3>3. Home Visit</h3>
                    <p>We'll schedule a home visit to ensure a good match.</p>
                </div>
                <div class="step">
                    <div class="step-icon"><i class="fas fa-heart"></i></div>
                    <h3>4. Finalize Adoption</h3>
                    <p>Complete paperwork and welcome your new family member!</p>
                </div>
            </div>
        </div>
    </section>

    <section class="featured-animals">
        <div class="container">
            <h2>Featured Pets</h2>
            <div class="animals-grid" id="featured-animals">
                <!-- Dynamically loaded from animals.js -->
            </div>
            <div class="text-center">
                <a href="animals.php" class="btn btn-primary">View All Animals</a>
            </div>
        </div>
    </section>

    <section id="about" class="about">
        <div class="container">
            <div class="about-content">
                <div class="about-text">
                    <h2>About Paws & Hearts</h2>
                    <p>We are a non-profit organization dedicated to rescuing abandoned and abused animals and finding them loving forever homes. Since our founding in 2010, we've helped over 5,000 animals find their perfect families.</p>
                    <p>Our team of volunteers and staff work tirelessly to provide medical care, rehabilitation, and love to animals in need until they can be placed with adopters who will cherish them.</p>
                    <a href="#" class="btn btn-secondary">Learn More About Us</a>
                </div>
                <div class="about-image">
                    <img src="https://images.unsplash.com/photo-1455103493930-a116f655b6c5?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80" alt="Volunteer with dog">
                </div>
            </div>
        </div>
    </section>

    <section id="contact" class="contact">
        <div class="container">
            <h2>Contact Us</h2>
            <div class="contact-container">
                <div class="contact-info">
                    <h3>Get in Touch</h3>
                    <p><i class="fas fa-map-marker-alt"></i> 123 Pet Lane, Animal City, AC 12345</p>
                    <p><i class="fas fa-phone"></i> (123) 456-7890</p>
                    <p><i class="fas fa-envelope"></i> info@pawsandhearts.org</p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-facebook"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
                <form class="contact-form">
                    <div class="form-group">
                        <input type="text" placeholder="Your Name" required>
                    </div>
                    <div class="form-group">
                        <input type="email" placeholder="Your Email" required>
                    </div>
                    <div class="form-group">
                        <input type="text" placeholder="Subject">
                    </div>
                    <div class="form-group">
                        <textarea placeholder="Your Message" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Send Message</button>
                </form>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>Paws & Hearts</h3>
                    <p>Dedicated to rescuing animals and finding them loving homes since 2010.</p>
                </div>
                <div class="footer-section">
                    <h3>Quick Links</h3>
                    <ul>
                        <li><a href="home.php">Home</a></li>
                        <li><a href="animals.php">Adopt</a></li>
                        <li><a href="about.html">About Us</a></li>
                        <li><a href="contact.html">Contact</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3>Adoption Info</h3>
                    <ul>
                        <li><a href="#">Adoption Process</a></li>
                        <li><a href="#">Fees</a></li>
                        <li><a href="#">Pre-Adoption Form</a></li>
                        <li><a href="#">FAQ</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3>Newsletter</h3>
                    <p>Subscribe to our newsletter for updates on new arrivals and events.</p>
                    <form class="newsletter-form">
                        <input type="email" placeholder="Your Email">
                        <button type="submit"><i class="fas fa-paper-plane"></i></button>
                    </form>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <div class="container">
                <p>&copy; 2023 Paws & Hearts Animal Adoption. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="js/main.js"></script>
    <script src="js/animals.js"></script>
</body>
</html>