<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Dashboard - Paws & Hearts</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<style>
/* General Reset */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f5f6fa;
    color: #333;
}
a {
    text-decoration: none;
    color: inherit;
}
ul {
    list-style: none;
}

/* Header */
header {
    background-color: #fff;
    border-bottom: 1px solid #ddd;
    padding: 1rem 0;
}
nav {
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.logo h1 {
    font-size: 1.5rem;
    color: #e67e22;
}
.nav-links {
    display: flex;
    gap: 1rem;
}
.nav-links li a {
    padding: 0.5rem 1rem;
    color: #555;
    font-weight: 500;
}
.nav-links li a.active,
.nav-links li a:hover {
    color: #e67e22;
}
.btn {
    background-color: #e67e22;
    color: white;
    padding: 0.5rem 1rem;
    border-radius: 20px;
    font-weight: bold;
}
.burger {
    display: none;
}

/* Layout */
.dashboard-container {
    display: flex;
    margin-top: 2rem;
    gap: 2rem;
}
.dashboard-sidebar {
    width: 250px;
    background-color: #fff;
    padding: 1rem;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0,0,0,0.05);
}
.dashboard-content {
    flex: 1;
}

/* Profile */
.user-profile {
    text-align: center;
    margin-bottom: 2rem;
}
.profile-image img {
    width: 80px;
    height: 80px;
    border-radius: 50%;
}
.profile-info h3 {
    margin: 0.5rem 0 0.2rem;
}
.profile-info p {
    font-size: 0.9rem;
    color: #888;
}

/* Sidebar Navigation */
.dashboard-menu ul li {
    margin: 0.7rem 0;
}
.dashboard-menu ul li a {
    display: flex;
    align-items: center;
    padding: 0.6rem;
    border-radius: 5px;
    color: #333;
    transition: background 0.3s;
}
.dashboard-menu ul li a i {
    margin-right: 0.6rem;
}
.dashboard-menu ul li a:hover,
.dashboard-menu ul li.active a {
    background-color: #e67e22;
    color: white;
}

/* Dashboard Header */
.dashboard-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
}
.dashboard-header h2 {
    font-size: 1.5rem;
}

/* Widgets */
.dashboard-widgets {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 1rem;
    margin-bottom: 2rem;
}
.widget {
    background: white;
    padding: 1rem;
    border-radius: 10px;
    display: flex;
    align-items: center;
    gap: 1rem;
    box-shadow: 0 0 10px rgba(0,0,0,0.05);
}
.widget-icon {
    font-size: 1.8rem;
    padding: 0.8rem;
    border-radius: 50%;
    color: white;
}
.success { background: #2ecc71; }
.warning { background: #f1c40f; }
.primary { background: #e67e22; }
.info { background: #3498db; }
.widget-info h3 {
    margin-bottom: 0.3rem;
    font-size: 1rem;
}
.widget-info p {
    font-size: 1.2rem;
    font-weight: bold;
}

/* Table */
.dashboard-section {
    margin-top: 2rem;
}
.dashboard-section h3 {
    margin-bottom: 1rem;
}
.table-responsive {
    overflow-x: auto;
}
.applications-table {
    width: 100%;
    border-collapse: collapse;
}
.applications-table th,
.applications-table td {
    padding: 0.8rem;
    border-bottom: 1px solid #eee;
    text-align: left;
}
.animal-info {
    display: flex;
    align-items: center;
    gap: 0.8rem;
}
.animal-info img {
    width: 50px;
    height: 50px;
    border-radius: 10px;
}
.status-badge {
    padding: 0.3rem 0.7rem;
    border-radius: 15px;
    font-size: 0.85rem;
    color: white;
}
.status-badge.approved {
    background-color: #2ecc71;
}
.status-badge.pending {
    background-color: #f39c12;
}
.btn-sm {
    padding: 0.3rem 0.7rem;
    font-size: 0.85rem;
}
.btn-link {
    color: #e67e22;
    font-weight: bold;
}
.text-right {
    text-align: right;
}

/* Animals grid */
.animals-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
    gap: 1rem;
}
.mini-grid {
    margin-top: 1rem;
}

/* Footer */
footer {
    margin-top: 3rem;
    background-color: #fff;
    padding: 1rem;
    text-align: center;
    font-size: 0.9rem;
    color: #999;
    border-top: 1px solid #ddd;
}
</style>
</head>
<body>
    <header>
        <div class="container">
            <nav>
                <div class="logo">
                    <h1><i class="fas fa-paw"></i> Paws & Hearts</h1>
                </div>
                <ul class="nav-links">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="animals.php">Animals</a></li>
                    <li><a href="dashboard.php" class="active">Dashboard</a></li>
                    <li><a href="contact.html">Contact</a></li>
                    <li><a href="#" id="logoutBtn" class="btn">Logout</a></li>
                </ul>
                <div class="burger">
                    <i class="fas fa-bars"></i>
                </div>
            </nav>
        </div>
    </header>

    <section class="dashboard">
        <div class="container">
            <div class="dashboard-container">
                <aside class="dashboard-sidebar">
                    <div class="user-profile">
                        <div class="profile-image">
                            <img src="https://images.unsplash.com/photo-1531123897727-8f129e1688ce?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80" alt="User profile">
                        </div>
                        <div class="profile-info">
                            <h3>John Doe</h3>
                            <p>Member since: June 2022</p>
                        </div>
                    </div>
                    <nav class="dashboard-menu">
                        <ul>
                            <li class="active"><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                            <li><a href="dashboard-applications.php"><i class="fas fa-file-alt"></i> My Applications</a></li>
                            <li><a href="favorites.php"><i class="fas fa-heart"></i> Favorites</a></li>
                            <li><form method="GET" action="cancel.php" style="margin:0;padding:0;">
                                <button type="submit" style="background: none; border: none; display: flex; align-items: center; padding: 0.6rem; width: 100%; text-align: left; cursor: pointer;">
                                    <i class="fas fa-times-circle" style="margin-right: 0.6rem;"></i> Cancellations
                                </button>
                            </form></li>
                        </ul>
                    </nav>
                </aside>
                <main class="dashboard-content">
                    <div class="dashboard-header">
                        <h2>My Dashboard</h2>
                        <div class="dashboard-actions">
                            <a href="animals.php" class="btn btn-primary"><i class="fas fa-paw"></i> Browse Animals</a>
                        </div>
                    </div>
                    
                    <div class="dashboard-widgets">
                        <div class="widget">
                            <div class="widget-icon success">
                                <i class="fas fa-check-circle"></i>
                            </div>
                            <div class="widget-info">
                                <h3>Approved Applications</h3>
                                <p>2</p>
                            </div>
                        </div>
                        <div class="widget">
                            <div class="widget-icon warning">
                                <i class="fas fa-clock"></i>
                            </div>
                            <div class="widget-info">
                                <h3>Pending Applications</h3>
                                <p>1</p>
                            </div>
                        </div>
                        <div class="widget">
                            <div class="widget-icon primary">
                                <i class="fas fa-heart"></i>
                            </div>
                            <div class="widget-info">
                                <h3>Favorite Animals</h3>
                                <p>5</p>
                            </div>
                        </div>
                        <div class="widget">
                            <div class="widget-icon info">
                                <i class="fas fa-envelope"></i>
                            </div>
                            <div class="widget-info">
                                <h3>New Messages</h3>
                                <p>3</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="dashboard-section">
                        <h3>Recent Applications</h3>
                        <div class="table-responsive">
                            <table class="applications-table">
                                <thead>
                                    <tr>
                                        <th>Animal</th>
                                        <th>Date Applied</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>
                                            <div class="animal-info">
                                                <img src="https://images.unsplash.com/photo-1561037404-61cd46aa615b?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80" alt="Buddy">
                                                <span>Buddy</span>
                                            </div>
                                        </td>
                                        <td>June 15, 2023</td>
                                        <td><span class="status-badge approved">Approved</span></td>
                                        <td>
                                            <button class="btn btn-sm btn-primary">View</button>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="animal-info">
                                                <img src="https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80" alt="Whiskers">
                                                <span>Whiskers</span>
                                            </div>
                                        </td>
                                        <td>June 10, 2023</td>
                                        <td><span class="status-badge pending">Pending</span></td>
                                        <td>
                                            <button class="btn btn-sm btn-primary">View</button>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="animal-info">
                                                <img src="https://images.unsplash.com/photo-1586671267731-da2cf3ceeb80?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80" alt="Max">
                                                <span>Max</span>
                                            </div>
                                        </td>
                                        <td>May 28, 2023</td>
                                        <td><span class="status-badge approved">Approved</span></td>
                                        <td>
                                            <button class="btn btn-sm btn-primary">View</button>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="text-right">
                            <a href="dashboard-applications.php" class="btn btn-link">View All Applications</a>
                        </div>
                    </div>
                    
                    <div class="dashboard-section">
                        <h3>Recommended Animals</h3>
                        <div class="animals-grid mini-grid">
                            <!-- Dynamically loaded from animals.js -->
                        </div>
                    </div>
                </main>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <p>&copy; 2023 Paws & Hearts Animal Adoption. All rights reserved.</p>
        </div>
    </footer>

    <script>
        // Disable any JavaScript that might be interfering with navigation
        document.addEventListener('DOMContentLoaded', function() {
            // Find and temporarily disable potentially problematic scripts
            const disableScripts = function() {
                try {
                    // Store original functions that might be causing issues
                    if (window.originalAddEventListener === undefined && window.addEventListener) {
                        window.originalAddEventListener = window.addEventListener;
                        window.addEventListener = function(type, listener, options) {
                            // Allow only essential events, block potential navigation interceptors
                            if (type !== 'click' && type !== 'beforeunload') {
                                window.originalAddEventListener(type, listener, options);
                            }
                        };
                    }
                } catch (e) {
                    console.error("Error disabling scripts:", e);
                }
            };
            
            disableScripts();
        });
    </script>
    
    <script src="js/auth.js"></script>
    <script src="js/animals.js"></script>
    <script src="js/main.js"></script>
</body>
</html>