<?php
session_start();
require 'db.php'; // Your DB connection file

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if (isset($_GET['animal_id'])) {
    $animal_id = intval($_GET['animal_id']);
    $user_id = $_SESSION['user_id'];

    // Check if this favorite already exists
    $check_sql = "SELECT id FROM favorites WHERE user_id = ? AND animal_id = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("ii", $user_id, $animal_id);
    $check_stmt->execute();
    $check_stmt->store_result();

    if ($check_stmt->num_rows === 0) {
        // Add to favorites
        $insert_sql = "INSERT INTO favorites (user_id, animal_id, created_at) VALUES (?, ?, NOW())";
        $insert_stmt = $conn->prepare($insert_sql);
        $insert_stmt->bind_param("ii", $user_id, $animal_id);
        $insert_stmt->execute();
    }

    // Redirect to favorites page
    header("Location: favorites.php");
    exit();
} else {
    echo "Invalid request. No animal selected.";
}
?>
