<?php
// Initialize the session
session_start();

// Check if the user is logged in, if not redirect to login page
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: login.php");
    exit;
}

// Make sure user ID is set before proceeding - FIXED: changed from "id" to "user_id"
if (!isset($_SESSION["user_id"])) {
    // Redirect to login page if user ID is not set
    header("location: login.php");
    exit;
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "2424";
$dbname = "paws";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Define variables and initialize with empty values
$request_id = $error = $success_message = "";
$reason = $additional_notes = "";

// Processing form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate request ID
    if (empty(trim($_POST["request_id"]))) {
        $error = "Invalid request.";
    } else {
        $request_id = trim($_POST["request_id"]);
        $reason = !empty($_POST["reason"]) ? trim($_POST["reason"]) : NULL;
        $additional_notes = !empty($_POST["additional_notes"]) ? trim($_POST["additional_notes"]) : NULL;
        
        // Check if the request belongs to the logged-in user - FIXED: changed from "id" to "user_id"
        $user_id = $_SESSION["user_id"];
        $sql = "SELECT ar.*, a.id as animal_id FROM adoption_requests ar 
                JOIN animals a ON ar.animal_id = a.id 
                WHERE ar.id = ? AND ar.user_id = ?";
        
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("ii", $request_id, $user_id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows == 1) {
                $request_data = $result->fetch_assoc();
                
                // Begin transaction
                $conn->begin_transaction();
                
                try {
                    // Insert into cancellations table
                    $insert_sql = "INSERT INTO cancellations (request_id, user_id, animal_id, reason, additional_notes, original_request_date, cancelled_by) 
                                  VALUES (?, ?, ?, ?, ?, ?, 'user')";
                    
                    $insert_stmt = $conn->prepare($insert_sql);
                    $insert_stmt->bind_param("iiisss", $request_id, $user_id, $request_data['animal_id'], $reason, $additional_notes, $request_data['request_date']);
                    $insert_stmt->execute();
                    $insert_stmt->close();
                    
                    // Delete from adoption_requests
                    $delete_sql = "DELETE FROM adoption_requests WHERE id = ?";
                    $delete_stmt = $conn->prepare($delete_sql);
                    $delete_stmt->bind_param("i", $request_id);
                    $delete_stmt->execute();
                    $delete_stmt->close();
                    
                    // Commit transaction
                    $conn->commit();
                    $success_message = "Your adoption request has been successfully cancelled.";
                    
                } catch (Exception $e) {
                    // Rollback transaction on error
                    $conn->rollback();
                    $error = "Something went wrong. Please try again later.";
                }
            } else {
                $error = "You don't have permission to cancel this request or the request doesn't exist.";
            }
            $stmt->close();
        }
    }
}

// Fetch all adoption requests for the current user - FIXED: changed from "id" to "user_id"
$user_id = $_SESSION["user_id"];
$sql = "SELECT ar.id, ar.request_date, ar.status, a.name, a.animal_type, a.breed 
        FROM adoption_requests ar 
        JOIN animals a ON ar.animal_id = a.id 
        WHERE ar.user_id = ? 
        ORDER BY ar.request_date DESC";

$requests = [];
if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $requests[] = $row;
    }
    $stmt->close();
}

// Debug: Check if user ID is correct and if there are any adoption requests in the database
$debug_message = "";
if (empty($requests)) {
    // Check if user ID exists in the session - FIXED: changed from "id" to "user_id"
    $debug_message .= "User ID: " . (isset($_SESSION["user_id"]) ? $_SESSION["user_id"] : "Not set") . "<br>";
    
    // Check if there are any adoption requests in the database for this user
    $check_sql = "SELECT COUNT(*) as count FROM adoption_requests WHERE user_id = ?";
    if ($check_stmt = $conn->prepare($check_sql)) {
        $check_stmt->bind_param("i", $user_id);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        $check_row = $check_result->fetch_assoc();
        $debug_message .= "Number of adoption requests found: " . $check_row['count'];
        $check_stmt->close();
    }
}

// Fetch all cancellations for the current user
$cancellations = [];
$sql = "SELECT c.id, c.cancelled_date, c.reason, c.additional_notes, c.original_request_date, 
        a.name, a.animal_type, a.breed 
        FROM cancellations c 
        JOIN animals a ON c.animal_id = a.id 
        WHERE c.user_id = ? 
        ORDER BY c.cancelled_date DESC";

if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        // Format the reason to be more user-friendly
        switch($row["reason"]) {
            case "changed_mind":
                $row["formatted_reason"] = "Changed my mind";
                break;
            case "found_another_pet":
                $row["formatted_reason"] = "Found another pet";
                break;
            case "personal_circumstances":
                $row["formatted_reason"] = "Personal circumstances changed";
                break;
            case "other":
                $row["formatted_reason"] = "Other";
                break;
            default:
                $row["formatted_reason"] = $row["reason"] ? ucfirst(str_replace('_', ' ', $row["reason"])) : "Not specified";
        }
        
        $cancellations[] = $row;
    }
    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Adoption Requests - PAWS Animal Shelter</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
            color: #333;
        }
        
        .container {
            width: 80%;
            margin: 2rem auto;
            padding: 2rem;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        
        h1, h2 {
            color: #4A6FA5;
            margin-bottom: 1.5rem;
        }
        
        h1 {
            text-align: center;
        }
        
        .section {
            margin-bottom: 2.5rem;
        }
        
        .alert {
            padding: 1rem;
            margin-bottom: 1rem;
            border-radius: 4px;
            text-align: center;
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .alert-info {
            background-color: #d1ecf1;
            color: #0c5460;
            border: 1px solid #bee5eb;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 2rem;
        }
        
        th, td {
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid #dee2e6;
        }
        
        th {
            background-color: #f0f0f0;
        }
        
        tr:hover {
            background-color: #f8f9fa;
        }
        
        .btn {
            display: inline-block;
            font-weight: 400;
            text-align: center;
            white-space: nowrap;
            vertical-align: middle;
            user-select: none;
            border: 1px solid transparent;
            padding: 0.375rem 0.75rem;
            font-size: 0.9rem;
            line-height: 1.5;
            border-radius: 0.25rem;
            transition: color 0.15s ease-in-out, background-color 0.15s ease-in-out, border-color 0.15s ease-in-out;
            text-decoration: none;
            cursor: pointer;
        }
        
        .btn-danger {
            color: #fff;
            background-color: #dc3545;
            border-color: #dc3545;
        }
        
        .btn-danger:hover {
            background-color: #c82333;
            border-color: #bd2130;
        }
        
        .btn-primary {
            color: #fff;
            background-color: #4A6FA5;
            border-color: #4A6FA5;
        }
        
        .btn-primary:hover {
            background-color: #3d5c8a;
            border-color: #38557f;
        }
        
        .back-link {
            display: block;
            text-align: center;
            margin-top: 1rem;
        }
        
        .empty-state {
            text-align: center;
            padding: 2rem;
            color: #6c757d;
        }
        
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.4);
        }
        
        .modal-content {
            background-color: #fefefe;
            margin: 15% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            max-width: 500px;
            border-radius: 8px;
        }
        
        .modal-actions {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 20px;
        }
        
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }
        
        .form-group {
            margin-bottom: 1rem;
        }
        
        .form-control {
            display: block;
            width: 100%;
            padding: 0.375rem 0.75rem;
            font-size: 1rem;
            line-height: 1.5;
            color: #495057;
            background-color: #fff;
            background-clip: padding-box;
            border: 1px solid #ced4da;
            border-radius: 0.25rem;
            transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
        }
        
        select.form-control {
            height: calc(2.25rem + 2px);
        }
        
        textarea.form-control {
            height: auto;
        }
        
        label {
            display: inline-block;
            margin-bottom: 0.5rem;
        }
        
        .text-warning {
            color: #ffc107;
        }
        
        .text-success {
            color: #28a745;
        }
        
        .text-danger {
            color: #dc3545;
        }
        
        .tab-navigation {
            display: flex;
            margin-bottom: 1.5rem;
            border-bottom: 1px solid #dee2e6;
        }
        
        .tab-button {
            padding: 0.75rem 1rem;
            background: none;
            border: none;
            border-bottom: 3px solid transparent;
            cursor: pointer;
            font-weight: 500;
            margin-right: 1rem;
            transition: all 0.3s;
        }
        
        .tab-button.active {
            color: #4A6FA5;
            border-bottom-color: #4A6FA5;
        }
        
        .tab-content {
            display: none;
        }
        
        .tab-content.active {
            display: block;
        }
        
        .notes-cell {
            max-width: 200px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .show-notes {
            color: #4A6FA5;
            cursor: pointer;
            text-decoration: underline;
        }
        
        .notes-modal {
            max-width: 600px !important;
        }

        .debug-info {
            margin-top: 20px;
            padding: 10px;
            background-color: #f8f9fa;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Manage Adoption Requests</h1>
        
        <?php if(!empty($error)): ?>
            <div class="alert alert-danger">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>
        
        <?php if(!empty($success_message)): ?>
            <div class="alert alert-success">
                <?php echo $success_message; ?>
            </div>
        <?php endif; ?>
        
        <div class="tab-navigation">
            <button class="tab-button active" data-tab="active-requests">Active Requests</button>
            <button class="tab-button" data-tab="cancelled-requests">Cancelled Requests</button>
        </div>
        
        <div id="active-requests" class="tab-content active">
            <?php if(!empty($debug_message)): ?>
                <div class="alert alert-info">
                    <p>Debug Information:</p>
                    <?php echo $debug_message; ?>
                </div>
            <?php endif; ?>
            
            <?php if(empty($requests)): ?>
                <div class="empty-state">
                    <p>You don't have any active adoption requests.</p>
                    <a href="animals.php" class="btn btn-primary">Browse Animals</a>
                </div>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Animal</th>
                            <th>Type</th>
                            <th>Breed</th>
                            <th>Request Date</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($requests as $request): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($request["name"]); ?></td>
                                <td><?php echo htmlspecialchars(ucfirst($request["animal_type"])); ?></td>
                                <td><?php echo htmlspecialchars($request["breed"]); ?></td>
                                <td><?php echo date("M d, Y", strtotime($request["request_date"])); ?></td>
                                <td>
                                    <?php 
                                        $status_class = "";
                                        switch($request["status"]) {
                                            case "pending":
                                                $status_class = "text-warning";
                                                break;
                                            case "approved":
                                                $status_class = "text-success";
                                                break;
                                            case "rejected":
                                                $status_class = "text-danger";
                                                break;
                                        }
                                    ?>
                                    <span class="<?php echo $status_class; ?>">
                                        <?php echo ucfirst($request["status"]); ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if($request["status"] == "pending"): ?>
                                        <button class="btn btn-danger" onclick="openModal(<?php echo $request['id']; ?>, '<?php echo htmlspecialchars($request["name"]); ?>')">Cancel</button>
                                    <?php else: ?>
                                        <span>-</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
        
        <div id="cancelled-requests" class="tab-content">
            <?php if(empty($cancellations)): ?>
                <div class="empty-state">
                    <p>You don't have any cancelled adoption requests.</p>
                </div>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Animal</th>
                            <th>Type</th>
                            <th>Breed</th>
                            <th>Original Request Date</th>
                            <th>Cancelled Date</th>
                            <th>Reason</th>
                            <th>Notes</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($cancellations as $cancellation): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($cancellation["name"]); ?></td>
                                <td><?php echo htmlspecialchars(ucfirst($cancellation["animal_type"])); ?></td>
                                <td><?php echo htmlspecialchars($cancellation["breed"]); ?></td>
                                <td><?php echo date("M d, Y", strtotime($cancellation["original_request_date"])); ?></td>
                                <td><?php echo date("M d, Y", strtotime($cancellation["cancelled_date"])); ?></td>
                                <td><?php echo htmlspecialchars($cancellation["formatted_reason"]); ?></td>
                                <td>
                                    <?php if(!empty($cancellation["additional_notes"])): ?>
                                        <div class="notes-cell">
                                            <?php echo htmlspecialchars($cancellation["additional_notes"]); ?>
                                        </div>
                                        <span class="show-notes" onclick="showNotes('<?php echo htmlspecialchars(addslashes($cancellation["additional_notes"])); ?>')">Show full notes</span>
                                    <?php else: ?>
                                        <span>-</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
        
        <a href="dashboard.php" class="back-link">Back to Dashboard</a>
    </div>
    
    <!-- Confirmation Modal -->
    <div id="confirmModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <h2>Confirm Cancellation</h2>
            <p>Are you sure you want to cancel your adoption request for <span id="animalName"></span>?</p>
            
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <div class="form-group">
                    <label for="reason">Reason for cancellation:</label>
                    <select name="reason" id="reason" class="form-control">
                        <option value="changed_mind">Changed my mind</option>
                        <option value="found_another_pet">Found another pet</option>
                        <option value="personal_circumstances">Personal circumstances changed</option>
                        <option value="other">Other</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="additional_notes">Additional notes (optional):</label>
                    <textarea name="additional_notes" id="additional_notes" class="form-control" rows="3"></textarea>
                </div>
                
                <input type="hidden" id="requestIdInput" name="request_id" value="">
                
                <div class="modal-actions">
                    <button type="button" class="btn btn-primary" onclick="closeModal()">No, Keep Request</button>
                    <button type="submit" class="btn btn-danger">Yes, Cancel Request</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Notes Modal -->
    <div id="notesModal" class="modal">
        <div class="modal-content notes-modal">
            <span class="close" onclick="closeNotesModal()">&times;</span>
            <h2>Additional Notes</h2>
            <div id="notesContent" style="margin-top: 1rem; white-space: pre-wrap;"></div>
            <div class="modal-actions">
                <button type="button" class="btn btn-primary" onclick="closeNotesModal()">Close</button>
            </div>
        </div>
    </div>
    
    <script>
        // Get the modals
        var confirmModal = document.getElementById("confirmModal");
        var notesModal = document.getElementById("notesModal");
        
        // Function to open the confirmation modal
        function openModal(requestId, animalName) {
            document.getElementById('requestIdInput').value = requestId;
            document.getElementById('animalName').textContent = animalName;
            confirmModal.style.display = "block";
        }
        
        // Function to close the confirmation modal
        function closeModal() {
            confirmModal.style.display = "none";
        }
        
        // Function to show notes in modal
        function showNotes(notes) {
            document.getElementById('notesContent').textContent = notes;
            notesModal.style.display = "block";
        }
        
        // Function to close the notes modal
        function closeNotesModal() {
            notesModal.style.display = "none";
        }
        
        // Close the modals when clicking outside of them
        window.onclick = function(event) {
            if (event.target == confirmModal) {
                closeModal();
            }
            if (event.target == notesModal) {
                closeNotesModal();
            }
        }
        
        // Tab navigation
        document.addEventListener('DOMContentLoaded', function() {
            const tabButtons = document.querySelectorAll('.tab-button');
            const tabContents = document.querySelectorAll('.tab-content');
            
            tabButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const tabId = this.getAttribute('data-tab');
                    
                    // Remove active class from all buttons and contents
                    tabButtons.forEach(btn => btn.classList.remove('active'));
                    tabContents.forEach(content => content.classList.remove('active'));
                    
                    // Add active class to clicked button and corresponding content
                    this.classList.add('active');
                    document.getElementById(tabId).classList.add('active');
                });
            });
        });
    </script>
</body>
</html>
