<?php
// Start session
session_start();

// Check if user is already logged in
if (isset($_SESSION['user_id'])) {
    // User is already logged in, redirect to home page
    header("Location: home.php");
    exit();
}

// Database connection - UPDATED CONNECTION METHOD
// Use try-catch to better handle connection errors
try {
    // First attempt: try with modified connection parameters
    $host = "127.0.0.1"; // Using IP instead of 'localhost' can resolve socket issues
    $dbname = "paws";
    $username = "root";
    $password = "2424";
    $port = 3306; // Explicitly specify the port
    
    // Create MySQL connection with PDO and explicit options
    $dsn = "mysql:host=$host;port=$port;dbname=$dbname;charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ];
    
    $pdo = new PDO($dsn, $username, $password, $options);
    
    // Successfully connected!
} catch (PDOException $e) {
    // If first connection attempt failed, try alternative approach
    try {
        // Alternative: try connecting without database name first
        $dsn = "mysql:host=127.0.0.1;port=3306";
        $pdo = new PDO($dsn, $username, $password, $options);
        
        // Check if database exists, create it if it doesn't
        $stmt = $pdo->query("SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '$dbname'");
        if ($stmt->rowCount() === 0) {
            // Database doesn't exist - create it
            $pdo->exec("CREATE DATABASE `$dbname`");
        }
        
        // Now connect with the database name
        $pdo = new PDO("mysql:host=127.0.0.1;port=3306;dbname=$dbname", $username, $password, $options);
    } catch (PDOException $innerException) {
        // Both connection attempts failed - display error
        die("Database connection failed: " . $innerException->getMessage());
    }
}

// Initialize variables
$email = $password = "";
$email_err = $password_err = $login_err = "";

// Process form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Add debug logging
    error_log("Form submitted");
    error_log("Email: " . $_POST["email"]);
    error_log("Password: " . $_POST["password"]);
    
    // Validate email
    if (empty(trim($_POST["email"]))) {
        $email_err = "Please enter your email.";
    } else {
        $email = trim($_POST["email"]);
    }
    
    // Validate password
    if (empty(trim($_POST["password"]))) {
        $password_err = "Please enter your password.";
    } else {
        $password = trim($_POST["password"]);
    }
    
    // Check if there are no validation errors
    if (empty($email_err) && empty($password_err)) {
        try {
            // Prepare a select statement
            $sql = "SELECT id, first_name, last_name, email, password, user_type FROM users WHERE email = :email";
            
            if ($stmt = $pdo->prepare($sql)) {
                // Bind variables to the prepared statement as parameters
                $stmt->bindParam(":email", $param_email, PDO::PARAM_STR);
                
                // Set parameters
                $param_email = $email;
                
                // Execute the prepared statement
                $stmt->execute();
                
                // Check if email exists
                if ($stmt->rowCount() == 1) {
                    if ($row = $stmt->fetch()) {
                        $id = $row["id"];
                        $firstname = $row["first_name"];
                        $lastname = $row["last_name"];
                        $email = $row["email"];
                        $hashed_password = $row["password"];
                        $user_type = $row["user_type"];
                        
                        // Verify password
                        if (password_verify($password, $hashed_password)) {
                            // Password is correct, start a new session
                            session_start();
                            
                            // Store data in session variables
                            $_SESSION["user_id"] = $id;
                            $_SESSION["first_name"] = $firstname;
                            $_SESSION["last_name"] = $lastname;
                            $_SESSION["email"] = $email;
                            $_SESSION["user_type"] = $user_type;
                            $_SESSION["loggedin"] = true;
                            
                            // Remember me functionality
                            if (isset($_POST["remember"]) && $_POST["remember"] == "on") {
                                // Create cookies that expire in 30 days
                                setcookie("user_email", $email, time() + (86400 * 30), "/");
                                setcookie("user_password", $password, time() + (86400 * 30), "/");
                            } else {
                                // Reset any existing cookies
                                if (isset($_COOKIE["user_email"])) {
                                    setcookie("user_email", "", time() - 3600, "/");
                                }
                                if (isset($_COOKIE["user_password"])) {
                                    setcookie("user_password", "", time() - 3600, "/");
                                }
                            }
                            
                            // Redirect user to home page
                            header("Location: home.php");
                            exit();
                        } else {
                            // Password is not valid
                            $login_err = "Invalid email or password.";
                        }
                    }
                } else {
                    // Email doesn't exist
                    $login_err = "Invalid email or password.";
                }
            } else {
                $login_err = "Oops! Something went wrong. Please try again later.";
            }
            
            // Close statement
            unset($stmt);
            
        } catch(PDOException $e) {
            $login_err = "Database error: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Paws & Hearts</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
    /* Reset and base styles */
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background-color: #f9f9f9;
        color: #333;
        line-height: 1.6;
    }

    a {
        color: #e07a5f;
        text-decoration: none;
    }

    a:hover {
        text-decoration: underline;
    }

    .container {
        width: 90%;
        max-width: 1200px;
        margin: auto;
    }

    /* Header */
    header {
        background-color: #fff;
        padding: 20px 0;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    nav {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .logo h1 {
        font-size: 1.8rem;
        color: #e07a5f;
    }

    .nav-links {
        list-style: none;
        display: flex;
        gap: 20px;
    }

    .nav-links li a {
        font-weight: 500;
        padding: 8px 12px;
        border-radius: 5px;
        transition: background 0.3s ease;
    }

    .nav-links li a:hover,
    .nav-links li a.btn {
        background-color: #e07a5f;
        color: white;
    }

    .burger {
        display: none;
        font-size: 24px;
        cursor: pointer;
    }

    /* Auth Section */
    .auth-section {
        padding: 60px 0;
        background-color: #fff;
    }

    .auth-container {
        display: flex;
        flex-wrap: wrap;
        gap: 40px;
        align-items: center;
        justify-content: center;
    }

    .auth-image img {
        max-width: 400px;
        width: 100%;
        border-radius: 10px;
    }

    .auth-form {
        max-width: 400px;
        width: 100%;
        background: #fefefe;
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0 0 15px rgba(0,0,0,0.05);
    }

    .auth-form h2 {
        color: #e07a5f;
        margin-bottom: 10px;
    }

    .auth-form p {
        margin-bottom: 20px;
    }

    .form-group {
        margin-bottom: 15px;
        position: relative;
    }

    .form-group label {
        display: block;
        margin-bottom: 5px;
    }

    .form-group input {
        width: 100%;
        padding: 10px 35px 10px 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }

    .form-group i {
        position: absolute;
        top: 50%;
        right: 10px;
        transform: translateY(-50%);
        color: #888;
    }

    .form-options {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 15px;
        font-size: 0.9rem;
    }

    .btn {
        display: inline-block;
        padding: 10px 20px;
        background-color: #e07a5f;
        color: #fff;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        transition: background 0.3s ease;
    }

    .btn:hover {
        background-color: #cf6143;
    }

    .btn-block {
        width: 100%;
        text-align: center;
    }

    .auth-alternative {
        text-align: center;
        margin-top: 15px;
    }

    .auth-social {
        margin-top: 30px;
        text-align: center;
    }

    .social-buttons {
        display: flex;
        justify-content: center;
        gap: 15px;
        margin-top: 10px;
    }

    .btn-social {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 10px 15px;
        border: none;
        border-radius: 5px;
        color: #fff;
        cursor: pointer;
    }

    .btn-facebook {
        background-color: #3b5998;
    }

    .btn-google {
        background-color: #db4437;
    }

    footer {
        background-color: #f1f1f1;
        padding: 20px 0;
        text-align: center;
        font-size: 0.9rem;
        color: #666;
        margin-top: 40px;
    }

    /* Error message styling */
    .alert {
        padding: 10px;
        margin-bottom: 15px;
        border-radius: 5px;
        color: #721c24;
        background-color: #f8d7da;
        border: 1px solid #f5c6cb;
    }

    .text-danger {
        color: #dc3545;
        font-size: 0.85rem;
        margin-top: 5px;
    }

    /* Responsive */
    @media (max-width: 768px) {
        .auth-container {
            flex-direction: column;
            text-align: center;
        }

        .nav-links {
            display: none;
        }

        .burger {
            display: block;
        }
    }
</style>
</head>
<body>
    <header>
        <div class="container">
            <nav>
                <div class="logo">
                    <h1><i class="fas fa-paw"></i> Paws & Hearts</h1>
                </div>
                <ul class="nav-links">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="animals.php">Animals</a></li>
                    <li><a href="about.html">About</a></li>
                    <li><a href="contact.html">Contact</a></li>
                    <li><a href="register.php" class="btn">Register</a></li>
                    <li><a href="dashboard.html" class="btn">My Dashboard</a></li>
                </ul>
                <div class="burger">
                    <i class="fas fa-bars"></i>
                </div>
            </nav>
        </div>
    </header>

    <section class="auth-section">
        <div class="container">
            <div class="auth-container">
                <div class="auth-image">
                    <img src="https://images.unsplash.com/photo-1583511655826-05700442b31b?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80" alt="Happy dog">
                </div>
                <div class="auth-form">
                    <h2>Welcome Back!</h2>
                    <p>Login to your account to continue your adoption journey.</p>
                    
                    <?php 
                    if(!empty($login_err)){
                        echo '<div class="alert">' . $login_err . '</div>';
                    }        
                    ?>
                    
                    <form id="loginForm" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" id="email" name="email" required value="<?php echo isset($_COOKIE['user_email']) ? $_COOKIE['user_email'] : $email; ?>">
                            <i class="fas fa-envelope"></i>
                            <?php if (!empty($email_err)) { echo '<span class="text-danger">' . $email_err . '</span>'; } ?>
                        </div>
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" id="password" name="password" required value="<?php echo isset($_COOKIE['user_password']) ? $_COOKIE['user_password'] : ''; ?>">
                            <i class="fas fa-lock"></i>
                            <?php if (!empty($password_err)) { echo '<span class="text-danger">' . $password_err . '</span>'; } ?>
                        </div>
                        <div class="form-options">
                            <div class="remember-me">
                                <input type="checkbox" id="remember" name="remember" <?php if(isset($_COOKIE['user_email'])) { echo "checked"; } ?>>
                                <label for="remember">Remember me</label>
                            </div>
                            <a href="forgot_password.php" class="forgot-password">Forgot password?</a>
                        </div>
                        <button type="submit" class="btn btn-primary btn-block">Login</button>
                        <div class="auth-alternative">
                            <p>Don't have an account? <a href="register.php">Register here</a></p>
                        </div>
                    </form>
                    
                    <div class="auth-social">
                        <p>Or login with</p>
                        <div class="social-buttons">
                            <button class="btn btn-social btn-facebook">
                                <i class="fab fa-facebook-f"></i> Facebook
                            </button>
                            <button class="btn btn-social btn-google">
                                <i class="fab fa-google"></i> Google
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <p>&copy; 2023 Paws & Hearts Animal Adoption. All rights reserved.</p>
        </div>
    </footer>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Toggle navigation menu for mobile
        const burger = document.querySelector('.burger');
        const nav = document.querySelector('.nav-links');
        
        if(burger) {
            burger.addEventListener('click', function() {
                nav.style.display = nav.style.display === 'flex' ? 'none' : 'flex';
            });
        }
    });
    </script>
</body>
</html>