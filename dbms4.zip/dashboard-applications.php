<?php
// Start the session to access user info
session_start();

// Check if user is logged in, if not redirect to login page
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Database connection
$servername = "localhost";
$username = "root"; // Replace with your DB username
$password = "2424"; // Replace with your DB password
$dbname = "paws"; // Replace with your DB name

// Create connection with mysqli
try {
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }
    
    // Get current user ID from session
    $user_id = $_SESSION['user_id'];
    
    // User query
    $userQuery = "SELECT * FROM users WHERE id = ?";
    $userStmt = $conn->prepare($userQuery);
    
    if (!$userStmt) {
        throw new Exception("User prepare failed: " . $conn->error);
    }
    
    $userStmt->bind_param("i", $user_id);
    $userStmt->execute();
    $userResult = $userStmt->get_result();
    
    if (!$userResult) {
        throw new Exception("User query failed: " . $conn->error);
    }
    
    $userData = $userResult->fetch_assoc();
    
    if (!$userData) {
        throw new Exception("No user data found for ID: " . $user_id);
    }

    // Check if the tables exist
    $check_tables = $conn->query("SHOW TABLES LIKE 'adoption_requests'");
    $adoption_requests_exists = $check_tables->num_rows > 0;
    $check_tables = $conn->query("SHOW TABLES LIKE 'animals'");
    $animals_exists = $check_tables->num_rows > 0;

    if (!$adoption_requests_exists || !$animals_exists) {
        throw new Exception("Error: One or more required tables don't exist. adoption_requests exists: " . 
            ($adoption_requests_exists ? "Yes" : "No") . ", animals exists: " . 
            ($animals_exists ? "Yes" : "No"));
    }

    // Query for adoption requests - Corrected JOIN clause with animal fields
    $sql = "SELECT ar.*, a.name as animal_name, a.image_url as animal_image, a.animal_type as species, a.breed 
            FROM adoption_requests ar
            JOIN animals a ON ar.animal_id = a.id
            WHERE ar.user_id = ?
            ORDER BY ar.request_date DESC";

    $stmt = $conn->prepare($sql);
    
    if (!$stmt) {
        // Prepare failed, use error handling with a direct query as fallback
        throw new Exception("Prepare failed: " . $conn->error);
    }
    
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Count applications by status
    $countSql = "SELECT 
                COUNT(CASE WHEN status = 'approved' THEN 1 END) as approved_count,
                COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_count,
                COUNT(CASE WHEN status = 'rejected' THEN 1 END) as rejected_count,
                COUNT(*) as total_count
            FROM adoption_requests 
            WHERE user_id = ?";
    
    $countStmt = $conn->prepare($countSql);
    
    if (!$countStmt) {
        throw new Exception("Count prepare failed: " . $conn->error);
    }
    
    $countStmt->bind_param("i", $user_id);
    $countStmt->execute();
    $countResult = $countStmt->get_result();
    
    if (!$countResult) {
        throw new Exception("Count query failed: " . $conn->error);
    }
    
    $counts = $countResult->fetch_assoc();
    
    // If no counts found, provide default values
    if (!$counts) {
        $counts = [
            'approved_count' => 0,
            'pending_count' => 0,
            'rejected_count' => 0,
            'total_count' => 0
        ];
    }

} catch (Exception $e) {
    // Display error message
    echo "<div style='margin: 50px auto; max-width: 800px; padding: 20px; background-color: #f8d7da; border: 1px solid #f5c6cb; border-radius: 5px;'>";
    echo "<h2 style='color: #721c24;'>Database Error</h2>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "<p>Please contact the administrator with this error message.</p>";
    echo "</div>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Applications - Paws & Hearts</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* General Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f6fa;
            color: #333;
        }
        a {
            text-decoration: none;
            color: inherit;
        }
        ul {
            list-style: none;
        }
        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
        }

        /* Header */
        header {
            background-color: #fff;
            border-bottom: 1px solid #ddd;
            padding: 1rem 0;
        }
        nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .logo h1 {
            font-size: 1.5rem;
            color: #e67e22;
        }
        .nav-links {
            display: flex;
            gap: 1rem;
        }
        .nav-links li a {
            padding: 0.5rem 1rem;
            color: #555;
            font-weight: 500;
        }
        .nav-links li a.active,
        .nav-links li a:hover {
            color: #e67e22;
        }
        .btn {
            background-color: #e67e22;
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-weight: bold;
            border: none;
            cursor: pointer;
        }
        .burger {
            display: none;
        }

        /* Layout */
        .dashboard-container {
            display: flex;
            margin-top: 2rem;
            gap: 2rem;
        }
        .dashboard-sidebar {
            width: 250px;
            background-color: #fff;
            padding: 1rem;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.05);
        }
        .dashboard-content {
            flex: 1;
        }

        /* Profile */
        .user-profile {
            text-align: center;
            margin-bottom: 2rem;
        }
        .profile-image img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            object-fit: cover;
        }
        .profile-info h3 {
            margin: 0.5rem 0 0.2rem;
        }
        .profile-info p {
            font-size: 0.9rem;
            color: #888;
        }

        /* Sidebar Navigation */
        .dashboard-menu ul li {
            margin: 0.7rem 0;
        }
        .dashboard-menu ul li a {
            display: flex;
            align-items: center;
            padding: 0.6rem;
            border-radius: 5px;
            color: #333;
            transition: background 0.3s;
        }
        .dashboard-menu ul li a i {
            margin-right: 0.6rem;
        }
        .dashboard-menu ul li a:hover,
        .dashboard-menu ul li.active a {
            background-color: #e67e22;
            color: white;
        }

        /* Dashboard Header */
        .dashboard-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
        }
        .dashboard-header h2 {
            font-size: 1.5rem;
        }

        /* Widgets */
        .dashboard-widgets {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
        }
        .widget {
            background: white;
            padding: 1rem;
            border-radius: 10px;
            display: flex;
            align-items: center;
            gap: 1rem;
            box-shadow: 0 0 10px rgba(0,0,0,0.05);
        }
        .widget-icon {
            font-size: 1.8rem;
            padding: 0.8rem;
            border-radius: 50%;
            color: white;
        }
        .success { background: #2ecc71; }
        .warning { background: #f1c40f; }
        .danger { background: #e74c3c; }
        .primary { background: #e67e22; }
        .info { background: #3498db; }
        .widget-info h3 {
            margin-bottom: 0.3rem;
            font-size: 1rem;
        }
        .widget-info p {
            font-size: 1.2rem;
            font-weight: bold;
        }

        /* Table */
        .dashboard-section {
            margin-top: 2rem;
            background-color: #fff;
            padding: 1.5rem;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.05);
        }
        .dashboard-section h3 {
            margin-bottom: 1rem;
            padding-bottom: 0.5rem;
            border-bottom: 1px solid #eee;
        }
        .table-responsive {
            overflow-x: auto;
        }
        .applications-table {
            width: 100%;
            border-collapse: collapse;
        }
        .applications-table th,
        .applications-table td {
            padding: 0.8rem;
            border-bottom: 1px solid #eee;
            text-align: left;
        }
        .applications-table th {
            background-color: #f8f9fa;
        }
        .animal-info {
            display: flex;
            align-items: center;
            gap: 0.8rem;
        }
        .animal-info img {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            object-fit: cover;
        }
        .animal-details h4 {
            margin-bottom: 0.3rem;
        }
        .animal-details p {
            font-size: 0.85rem;
            color: #888;
        }
        .status-badge {
            padding: 0.3rem 0.7rem;
            border-radius: 15px;
            font-size: 0.85rem;
            color: white;
            display: inline-block;
        }
        .status-badge.approved {
            background-color: #2ecc71;
        }
        .status-badge.pending {
            background-color: #f39c12;
        }
        .status-badge.rejected {
            background-color: #e74c3c;
        }
        .btn-sm {
            padding: 0.3rem 0.7rem;
            font-size: 0.85rem;
        }
        .btn-link {
            color: #e67e22;
            font-weight: bold;
        }
        .text-right {
            text-align: right;
        }
        .date-info {
            font-size: 0.9rem;
            color: #666;
        }
        .notes {
            font-style: italic;
            color: #777;
            margin-top: 0.3rem;
        }
        .empty-state {
            text-align: center;
            padding: 2rem;
            color: #888;
        }
        .empty-state i {
            font-size: 3rem;
            margin-bottom: 1rem;
            color: #ddd;
        }
        .text-muted {
            color: #888;
            font-style: italic;
        }
        .mt-3 {
            margin-top: 1rem;
        }
        
        /* Footer */
        footer {
            margin-top: 3rem;
            background-color: #fff;
            padding: 1rem;
            text-align: center;
            font-size: 0.9rem;
            color: #999;
            border-top: 1px solid #ddd;
        }
        
        /* Modal */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.4);
        }
        .modal-content {
            background-color: #fff;
            margin: 10% auto;
            padding: 1.5rem;
            border-radius: 10px;
            width: 80%;
            max-width: 600px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
            padding-bottom: 0.5rem;
            border-bottom: 1px solid #eee;
        }
        .modal-body {
            margin-bottom: 1.5rem;
        }
        .modal-footer {
            display: flex;
            justify-content: flex-end;
            gap: 0.5rem;
        }
        .close {
            color: #aaa;
            font-size: 1.5rem;
            font-weight: bold;
            cursor: pointer;
        }
        .close:hover {
            color: #555;
        }
        .application-detail-item {
            margin-bottom: 1rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid #eee;
        }
        .application-detail-item:last-child {
            border-bottom: none;
        }
        .application-detail-item h4 {
            margin-bottom: 0.5rem;
            color: #555;
        }
        .animal-info-container {
            display: flex;
            align-items: center;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .dashboard-container {
                flex-direction: column;
            }
            .dashboard-sidebar {
                width: 100%;
            }
            .nav-links {
                display: none;
            }
            .nav-links.active {
                display: flex;
                flex-direction: column;
                position: absolute;
                top: 60px;
                left: 0;
                right: 0;
                background: white;
                padding: 1rem;
                box-shadow: 0 5px 10px rgba(0,0,0,0.1);
                z-index: 10;
            }
            .burger {
                display: block;
                cursor: pointer;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <nav>
                <div class="logo">
                    <h1><i class="fas fa-paw"></i> Paws & Hearts</h1>
                </div>
                <ul class="nav-links">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="animals.php">Animals</a></li>
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li><a href="contact.html">Contact</a></li>
                    <li><a href="#" id="logoutBtn" class="btn">Logout</a></li>
                </ul>
                <div class="burger">
                    <i class="fas fa-bars"></i>
                </div>
            </nav>
        </div>
    </header>

    <section class="dashboard">
        <div class="container">
            <div class="dashboard-container">
                <aside class="dashboard-sidebar">
                    <div class="user-profile">
                        <div class="profile-image">
                            <img src="https://images.unsplash.com/photo-1531123897727-8f129e1688ce?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80" alt="User profile">
                        </div>
                        <div class="profile-info">
                            <h3><?php echo htmlspecialchars($userData['first_name'] . ' ' . $userData['last_name']); ?></h3>
                            <p>Member since: <?php echo date('F Y', strtotime($userData['created_at'])); ?></p>
                        </div>
                    </div>
                    <nav class="dashboard-menu">
                        <ul>
                            <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                            <li class="active"><a href="dashboard-applications.php"><i class="fas fa-file-alt"></i> My Applications</a></li>
                            <li><a href="dashboard-favorites.php"><i class="fas fa-heart"></i> Favorites</a></li>
                        </ul>
                    </nav>
                </aside>
                <main class="dashboard-content">
                    <div class="dashboard-header">
                        <h2>My Applications</h2>
                        <div class="dashboard-actions">
                            <a href="animals.php" class="btn btn-primary"><i class="fas fa-paw"></i> Browse Animals</a>
                        </div>
                    </div>
                    
                    <div class="dashboard-widgets">
                        <div class="widget">
                            <div class="widget-icon success">
                                <i class="fas fa-check-circle"></i>
                            </div>
                            <div class="widget-info">
                                <h3>Approved</h3>
                                <p><?php echo $counts['approved_count']; ?></p>
                            </div>
                        </div>
                        <div class="widget">
                            <div class="widget-icon warning">
                                <i class="fas fa-clock"></i>
                            </div>
                            <div class="widget-info">
                                <h3>Pending</h3>
                                <p><?php echo $counts['pending_count']; ?></p>
                            </div>
                        </div>
                        <div class="widget">
                            <div class="widget-icon danger">
                                <i class="fas fa-times-circle"></i>
                            </div>
                            <div class="widget-info">
                                <h3>Rejected</h3>
                                <p><?php echo $counts['rejected_count']; ?></p>
                            </div>
                        </div>
                        <div class="widget">
                            <div class="widget-icon primary">
                                <i class="fas fa-file-alt"></i>
                            </div>
                            <div class="widget-info">
                                <h3>Total Applications</h3>
                                <p><?php echo $counts['total_count']; ?></p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="dashboard-section">
                        <h3>All Applications</h3>
                        <div class="table-responsive">
                            <?php if (isset($result) && $result->num_rows > 0): ?>
                            <table class="applications-table">
                                <thead>
                                    <tr>
                                        <th>Animal</th>
                                        <th>Date Applied</th>
                                        <th>Status</th>
                                        <th>Notes</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while($row = $result->fetch_assoc()): ?>
                                    <tr data-id="<?php echo $row['id']; ?>">
                                        <td>
                                            <div class="animal-info">
                                                <img src="<?php echo !empty($row['animal_image']) ? htmlspecialchars($row['animal_image']) : 'https://images.unsplash.com/photo-1561037404-61cd46aa615b?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80'; ?>" alt="<?php echo htmlspecialchars($row['animal_name']); ?>">
                                                <div class="animal-details">
                                                    <h4><?php echo htmlspecialchars($row['animal_name']); ?></h4>
                                                    <p><?php echo htmlspecialchars($row['species'] . ' • ' . $row['breed']); ?></p>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="date-info">
                                                <?php echo date('F d, Y', strtotime($row['request_date'])); ?>
                                                <p><?php echo date('h:i A', strtotime($row['request_date'])); ?></p>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="status-badge <?php echo strtolower($row['status']); ?>">
                                                <?php echo ucfirst($row['status']); ?>
                                            </span>
                                            <?php if($row['processed_date']): ?>
                                                <p class="date-info">Processed on: <?php echo date('M d, Y', strtotime($row['processed_date'])); ?></p>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if(!empty($row['notes'])): ?>
                                                <div class="notes"><?php echo htmlspecialchars($row['notes']); ?></div>
                                            <?php else: ?>
                                                <span class="text-muted">No notes</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <button class="btn btn-sm btn-primary view-application" data-id="<?php echo $row['id']; ?>">View Details</button>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                            <?php else: ?>
                            <div class="empty-state">
                                <i class="fas fa-file-alt"></i>
                                <h3>No Applications Yet</h3>
                                <p>You haven't submitted any adoption applications yet.</p>
                                <a href="animals.php" class="btn btn-primary mt-3">Browse Animals to Adopt</a>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    </section>

    <!-- Application Details Modal -->
    <div id="applicationModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Application Details</h3>
                <span class="close">&times;</span>
            </div>
            <div class="modal-body" id="applicationDetails">
                <!-- Application details will be loaded here -->
            </div>
            <div class="modal-footer">
                <button class="btn" id="closeModal">Close</button>
            </div>
        </div>
    </div>

    <footer>
        <div class="container">
            <p>&copy; 2025 Paws & Hearts Animal Adoption. All rights reserved.</p>
        </div>
    </footer>

    <script>
        // Modal functionality
        const modal = document.getElementById("applicationModal");
        const closeBtn = document.getElementsByClassName("close")[0];
        const closeModalBtn = document.getElementById("closeModal");
        const applicationDetails = document.getElementById("applicationDetails");
        
        // Get all "View Details" buttons
        const viewButtons = document.querySelectorAll(".view-application");
        
        // Add click event to all view buttons
        viewButtons.forEach(button => {
            button.addEventListener("click", function() {
                const applicationId = this.getAttribute("data-id");
                // Here you would normally make an AJAX call to get the application details
                // For now, we'll just use the row data
                const row = this.closest("tr");
                
                // Get data from the row
                const animalInfo = row.querySelector(".animal-info").innerHTML;
                const dateInfo = row.querySelector(".date-info").innerHTML;
                const status = row.querySelector(".status-badge").outerHTML;
                const notes = row.querySelector("td:nth-child(4)").innerHTML;
                
                // Populate modal
                applicationDetails.innerHTML = `
                    <div class="application-detail-item">
                        <h4>Animal Information</h4>
                        <div class="animal-info-container">
                            ${animalInfo}
                        </div>
                    </div>
                    <div class="application-detail-item">
                        <h4>Application Status</h4>
                        <p>${status}</p>
                    </div>
                    <div class="application-detail-item">
                        <h4>Date Submitted</h4>
                        <p>${dateInfo}</p>
                    </div>
                    <div class="application-detail-item">
                        <h4>Notes</h4>
                        <div>${notes}</div>
                    </div>
                `;
                
                // Show modal
                modal.style.display = "block";
            });
        });
        
        // Close modal when clicking the X
        closeBtn.onclick = function() {
            modal.style.display = "none";
        }
        
        // Close modal when clicking the Close button
        closeModalBtn.onclick = function() {
            modal.style.display = "none";
        }
        
        // Close modal when clicking outside of it
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }
        
        // Mobile menu toggle
        const burger = document.querySelector('.burger');
        const navLinks = document.querySelector('.nav-links');
        
        burger.addEventListener('click', function() {
            navLinks.classList.toggle('active');
        });
        
        // Logout functionality
        document.getElementById('logoutBtn').addEventListener('click', function(e) {
            e.preventDefault();
            window.location.href = 'logout.php';
        });
    </script>
</body>
</html>

<?php
// Close database connection
$stmt->close();
$userStmt->close();
$countStmt->close();
$conn->close();
?>