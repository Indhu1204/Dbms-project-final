<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php');
    exit();
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "2424";
$dbname = "paws";

try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'approve_request':
                $request_id = $_POST['request_id'];
                $animal_id = $_POST['animal_id'];
                $stmt = $pdo->prepare("UPDATE adoption_requests SET status = 'approved', processed_by = ?, processed_date = NOW() WHERE id = ?");
                $stmt->execute([$_SESSION['admin_id'], $request_id]);
                
                // Update animal status to adopted
                $stmt = $pdo->prepare("UPDATE animals SET status = 'adopted' WHERE id = ?");
                $stmt->execute([$animal_id]);
                
                echo "<script>alert('Request approved successfully!');</script>";
                break;
                
            case 'reject_request':
                $request_id = $_POST['request_id'];
                $stmt = $pdo->prepare("UPDATE adoption_requests SET status = 'rejected', processed_by = ?, processed_date = NOW() WHERE id = ?");
                $stmt->execute([$_SESSION['admin_id'], $request_id]);
                echo "<script>alert('Request rejected successfully!');</script>";
                break;
                
            case 'update_animal':
                $animal_id = $_POST['animal_id'];
                $name = $_POST['name'];
                $status = $_POST['status'];
                $description = $_POST['description'];
                
                $stmt = $pdo->prepare("UPDATE animals SET name = ?, status = ?, description = ? WHERE id = ?");
                $stmt->execute([$name, $status, $description, $animal_id]);
                echo "<script>alert('Animal updated successfully!');</script>";
                break;
                
            case 'update_cancellation_status':
                $cancellation_id = $_POST['cancellation_id'];
                $status = $_POST['status'];
                
                try {
                    // First, let's check the current structure of the cancellations table
                    $stmt = $pdo->prepare("SHOW COLUMNS FROM cancellations LIKE 'status'");
                    $stmt->execute();
                    $statusColumn = $stmt->fetch(PDO::FETCH_ASSOC);
                    
                    if (!$statusColumn) {
                        // Status column doesn't exist, create it
                        $pdo->exec("ALTER TABLE cancellations ADD COLUMN status ENUM('pending', 'approved', 'rejected', 'processed') DEFAULT 'pending'");
                        echo "<script>alert('Status column created successfully!');</script>";
                    } else {
                        // Check the ENUM values in the existing status column
                        $type = $statusColumn['Type'];
                        preg_match("/enum\((.+)\)/i", $type, $matches);
                        if (isset($matches[1])) {
                            $enumValues = str_getcsv($matches[1], ',', "'");
                            
                            // If the current status value is not in the ENUM, we need to update the column
                            if (!in_array($status, $enumValues)) {
                                // Get current enum values and add our missing ones
                                $newEnumValues = array_unique(array_merge($enumValues, ['pending', 'approved', 'rejected', 'processed']));
                                $enumString = "'" . implode("','", $newEnumValues) . "'";
                                
                                $alterQuery = "ALTER TABLE cancellations MODIFY COLUMN status ENUM($enumString) DEFAULT 'pending'";
                                $pdo->exec($alterQuery);
                                echo "<script>alert('Status column updated with new values!');</script>";
                            }
                        }
                    }
                    
                    // Validate the status value before updating
                    $valid_statuses = ['pending', 'approved', 'rejected', 'processed'];
                    if (!in_array($status, $valid_statuses)) {
                        throw new Exception("Invalid status value: " . $status);
                    }
                    
                    // Now update the status
                    $stmt = $pdo->prepare("UPDATE cancellations SET status = ? WHERE id = ?");
                    $stmt->execute([$status, $cancellation_id]);
                    echo "<script>alert('Cancellation status updated successfully!');</script>";
                } catch (Exception $e) {
                    echo "<script>alert('Error updating cancellation status: " . addslashes($e->getMessage()) . "');</script>";
                }
                break;
        }
    }
}

// Fetch data for display with error handling
try {
    $pending_requests = $pdo->query("
        SELECT ar.*, u.first_name, u.last_name, u.email, a.name as animal_name 
        FROM adoption_requests ar 
        JOIN users u ON ar.user_id = u.id 
        JOIN animals a ON ar.animal_id = a.id 
        WHERE ar.status = 'pending'
        ORDER BY ar.request_date DESC
    ")->fetchAll(PDO::FETCH_ASSOC);

    $all_requests = $pdo->query("
        SELECT ar.*, u.first_name, u.last_name, u.email, a.name as animal_name 
        FROM adoption_requests ar 
        JOIN users u ON ar.user_id = u.id 
        JOIN animals a ON ar.animal_id = a.id 
        ORDER BY ar.request_date DESC
    ")->fetchAll(PDO::FETCH_ASSOC);

    $animals = $pdo->query("SELECT * FROM animals ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);

    // Modified cancellations query to handle cases where status column might not exist
    try {
        $cancellations = $pdo->query("
            SELECT c.*, u.first_name, u.last_name, u.email, a.name as animal_name 
            FROM cancellations c 
            JOIN users u ON c.user_id = u.id 
            JOIN animals a ON c.animal_id = a.id 
            ORDER BY c.cancelled_date DESC
        ")->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        // If there's an error (possibly due to missing status column), try without status
        $cancellations = $pdo->query("
            SELECT c.*, u.first_name, u.last_name, u.email, a.name as animal_name 
            FROM cancellations c 
            JOIN users u ON c.user_id = u.id 
            JOIN animals a ON c.animal_id = a.id 
            ORDER BY c.cancelled_date DESC
        ")->fetchAll(PDO::FETCH_ASSOC);
        
        // Add default status to each row if it doesn't exist
        foreach ($cancellations as &$cancellation) {
            if (!isset($cancellation['status'])) {
                $cancellation['status'] = 'pending';
            }
        }
    }
} catch (PDOException $e) {
    echo "<script>alert('Database error: " . addslashes($e->getMessage()) . "');</script>";
    // Initialize with empty arrays if queries fail
    $pending_requests = [];
    $all_requests = [];
    $animals = [];
    $cancellations = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Portal - PAWS</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            background-color: #f4f4f4;
        }
        
        .header {
            background: #2c3e50;
            color: white;
            padding: 1rem 0;
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
        }
        
        .nav {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
        }
        
        .nav h1 {
            font-size: 2rem;
        }
        
        .nav-links {
            display: flex;
            gap: 20px;
        }
        
        .nav-links a {
            color: white;
            text-decoration: none;
            padding: 10px 15px;
            border-radius: 5px;
            transition: background 0.3s;
        }
        
        .nav-links a:hover {
            background: #34495e;
        }
        
        .container {
            max-width: 1200px;
            margin: 80px auto 20px;
            padding: 20px;
        }
        
        .tab-container {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        
        .tab-buttons {
            display: flex;
            border-bottom: 1px solid #ddd;
        }
        
        .tab-button {
            padding: 15px 25px;
            background: none;
            border: none;
            cursor: pointer;
            font-size: 16px;
            color: #666;
            transition: all 0.3s;
        }
        
        .tab-button.active {
            background: #3498db;
            color: white;
        }
        
        .tab-content {
            display: none;
            padding: 20px;
        }
        
        .tab-content.active {
            display: block;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        
        th {
            background-color: #f8f9fa;
            font-weight: bold;
        }
        
        tr:hover {
            background-color: #f5f5f5;
        }
        
        .btn {
            padding: 8px 16px;
            margin: 2px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            font-size: 14px;
            transition: all 0.3s;
        }
        
        .btn-approve {
            background: #27ae60;
            color: white;
        }
        
        .btn-reject {
            background: #e74c3c;
            color: white;
        }
        
        .btn-edit {
            background: #3498db;
            color: white;
        }
        
        .btn:hover {
            opacity: 0.8;
            transform: translateY(-2px);
        }
        
        .status {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
        }
        
        .status-pending {
            background: #f39c12;
            color: white;
        }
        
        .status-approved {
            background: #27ae60;
            color: white;
        }
        
        .status-rejected {
            background: #e74c3c;
            color: white;
        }
        
        .status-processed {
            background: #8e44ad;
            color: white;
        }
        
        .status-available {
            background: #2ecc71;
            color: white;
        }
        
        .status-adopted {
            background: #9b59b6;
            color: white;
        }
        
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }
        
        .modal-content {
            background-color: white;
            margin: 15% auto;
            padding: 20px;
            border-radius: 10px;
            width: 80%;
            max-width: 500px;
        }
        
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }
        
        .close:hover {
            color: black;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        
        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }
        
        .form-group textarea {
            height: 100px;
            resize: vertical;
        }
        
        .error-message {
            background: #f8d7da;
            color: #721c24;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <header class="header">
        <nav class="nav">
            <h1>PAWS Admin Portal</h1>
            <div class="nav-links">
                <span>Welcome, <?php echo isset($_SESSION['admin_name']) ? htmlspecialchars($_SESSION['admin_name']) : 'Admin'; ?></span>
                <a href="logout.php">Logout</a>
            </div>
        </nav>
    </header>

    <div class="container">
        <div class="tab-container">
            <div class="tab-buttons">
                <button class="tab-button active" onclick="openTab(event, 'pending-requests')">Pending Requests</button>
                <button class="tab-button" onclick="openTab(event, 'all-requests')">All Requests</button>
                <button class="tab-button" onclick="openTab(event, 'animals')">Animals</button>
                <button class="tab-button" onclick="openTab(event, 'cancellations')">Cancellations</button>
            </div>

            <!-- Pending Requests Tab -->
            <div id="pending-requests" class="tab-content active">
                <h2>Pending Adoption Requests</h2>
                <?php if (empty($pending_requests)): ?>
                    <p>No pending requests found.</p>
                <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>User</th>
                            <th>Email</th>
                            <th>Animal</th>
                            <th>Request Date</th>
                            <th>Notes</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($pending_requests as $request): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($request['id']); ?></td>
                            <td><?php echo htmlspecialchars($request['first_name'] . ' ' . $request['last_name']); ?></td>
                            <td><?php echo htmlspecialchars($request['email']); ?></td>
                            <td><?php echo htmlspecialchars($request['animal_name']); ?></td>
                            <td><?php echo date('Y-m-d H:i', strtotime($request['request_date'])); ?></td>
                            <td><?php echo htmlspecialchars($request['notes'] ?: 'None'); ?></td>
                            <td>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="action" value="approve_request">
                                    <input type="hidden" name="request_id" value="<?php echo $request['id']; ?>">
                                    <input type="hidden" name="animal_id" value="<?php echo $request['animal_id']; ?>">
                                    <button type="submit" class="btn btn-approve" onclick="return confirm('Approve this request?')">Approve</button>
                                </form>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="action" value="reject_request">
                                    <input type="hidden" name="request_id" value="<?php echo $request['id']; ?>">
                                    <button type="submit" class="btn btn-reject" onclick="return confirm('Reject this request?')">Reject</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>

            <!-- All Requests Tab -->
            <div id="all-requests" class="tab-content">
                <h2>All Adoption Requests</h2>
                <?php if (empty($all_requests)): ?>
                    <p>No requests found.</p>
                <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>User</th>
                            <th>Animal</th>
                            <th>Request Date</th>
                            <th>Status</th>
                            <th>Processed Date</th>
                            <th>Notes</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($all_requests as $request): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($request['id']); ?></td>
                            <td><?php echo htmlspecialchars($request['first_name'] . ' ' . $request['last_name']); ?></td>
                            <td><?php echo htmlspecialchars($request['animal_name']); ?></td>
                            <td><?php echo date('Y-m-d H:i', strtotime($request['request_date'])); ?></td>
                            <td>
                                <span class="status status-<?php echo $request['status']; ?>">
                                    <?php echo ucfirst($request['status']); ?>
                                </span>
                            </td>
                            <td><?php echo $request['processed_date'] ? date('Y-m-d H:i', strtotime($request['processed_date'])) : 'N/A'; ?></td>
                            <td><?php echo htmlspecialchars($request['notes'] ?: 'None'); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>

            <!-- Animals Tab -->
            <div id="animals" class="tab-content">
                <h2>Animals Management</h2>
                <?php if (empty($animals)): ?>
                    <p>No animals found.</p>
                <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Type</th>
                            <th>Breed</th>
                            <th>Age Group</th>
                            <th>Size</th>
                            <th>Gender</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($animals as $animal): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($animal['id']); ?></td>
                            <td><?php echo htmlspecialchars($animal['name']); ?></td>
                            <td><?php echo ucfirst(htmlspecialchars($animal['animal_type'])); ?></td>
                            <td><?php echo htmlspecialchars($animal['breed']); ?></td>
                            <td><?php echo ucfirst(htmlspecialchars($animal['age_group'])); ?></td>
                            <td><?php echo ucfirst(htmlspecialchars($animal['size'])); ?></td>
                            <td><?php echo ucfirst(htmlspecialchars($animal['gender'])); ?></td>
                            <td>
                                <span class="status status-<?php echo $animal['status']; ?>">
                                    <?php echo ucfirst($animal['status']); ?>
                                </span>
                            </td>
                            <td>
                                <button class="btn btn-edit" onclick="editAnimal(<?php echo htmlspecialchars(json_encode($animal)); ?>)">Edit</button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>

            <!-- Cancellations Tab -->
            <div id="cancellations" class="tab-content">
                <h2>Cancellations Management</h2>
                <?php if (empty($cancellations)): ?>
                    <p>No cancellations found.</p>
                <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>User</th>
                            <th>Animal</th>
                            <th>Cancelled Date</th>
                            <th>Reason</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($cancellations as $cancellation): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($cancellation['id']); ?></td>
                            <td><?php echo htmlspecialchars($cancellation['first_name'] . ' ' . $cancellation['last_name']); ?></td>
                            <td><?php echo htmlspecialchars($cancellation['animal_name']); ?></td>
                            <td><?php echo date('Y-m-d H:i', strtotime($cancellation['cancelled_date'])); ?></td>
                            <td><?php echo $cancellation['reason'] ? ucfirst(str_replace('_', ' ', htmlspecialchars($cancellation['reason']))) : 'N/A'; ?></td>
                            <td>
                                <?php $status = $cancellation['status'] ?? 'pending'; ?>
                                <span class="status status-<?php echo $status; ?>">
                                    <?php echo ucfirst($status); ?>
                                </span>
                            </td>
                            <td>
                                <button class="btn btn-edit" onclick="editCancellation(<?php echo $cancellation['id']; ?>, '<?php echo $status; ?>')">Update Status</button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Edit Animal Modal -->
    <div id="animalModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h3>Edit Animal</h3>
            <form method="POST">
                <input type="hidden" name="action" value="update_animal">
                <input type="hidden" name="animal_id" id="edit_animal_id">
                
                <div class="form-group">
                    <label for="edit_name">Name:</label>
                    <input type="text" name="name" id="edit_name" required>
                </div>
                
                <div class="form-group">
                    <label for="edit_status">Status:</label>
                    <select name="status" id="edit_status" required>
                        <option value="available">Available</option>
                        <option value="pending">Pending</option>
                        <option value="adopted">Adopted</option>
                        <option value="fostered">Fostered</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="edit_description">Description:</label>
                    <textarea name="description" id="edit_description"></textarea>
                </div>
                
                <button type="submit" class="btn btn-approve">Update Animal</button>
            </form>
        </div>
    </div>

    <!-- Edit Cancellation Modal -->
    <div id="cancellationModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h3>Update Cancellation Status</h3>
            <form method="POST">
                <input type="hidden" name="action" value="update_cancellation_status">
                <input type="hidden" name="cancellation_id" id="edit_cancellation_id">
                
                <div class="form-group">
                    <label for="edit_cancellation_status">Status:</label>
                    <select name="status" id="edit_cancellation_status" required>
                        <option value="pending">Pending</option>
                        <option value="approved">Approved</option>
                        <option value="rejected">Rejected</option>
                        <option value="processed">Processed</option>
                    </select>
                </div>
                
                <button type="submit" class="btn btn-approve">Update Status</button>
            </form>
        </div>
    </div>

    <script>
        function openTab(evt, tabName) {
            var i, tabcontent, tablinks;
            tabcontent = document.getElementsByClassName("tab-content");
            for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].classList.remove("active");
            }
            tablinks = document.getElementsByClassName("tab-button");
            for (i = 0; i < tablinks.length; i++) {
                tablinks[i].classList.remove("active");
            }
            document.getElementById(tabName).classList.add("active");
            evt.currentTarget.classList.add("active");
        }

        function editAnimal(animal) {
            document.getElementById('edit_animal_id').value = animal.id;
            document.getElementById('edit_name').value = animal.name;
            document.getElementById('edit_status').value = animal.status;
            document.getElementById('edit_description').value = animal.description || '';
            document.getElementById('animalModal').style.display = 'block';
        }

        function editCancellation(id, status) {
            document.getElementById('edit_cancellation_id').value = id;
            document.getElementById('edit_cancellation_status').value = status || 'pending';
            document.getElementById('cancellationModal').style.display = 'block';
        }

        // Modal close functionality
        var modals = document.getElementsByClassName('modal');
        var closes = document.getElementsByClassName('close');

        for (let i = 0; i < closes.length; i++) {
            closes[i].onclick = function() {
                modals[i].style.display = 'none';
            }
        }

        window.onclick = function(event) {
            for (let i = 0; i < modals.length; i++) {
                if (event.target == modals[i]) {
                    modals[i].style.display = 'none';
                }
            }
        }
    </script>
</body>
</html>