<?php
// Start session
session_start();

// Include database connection
require_once 'db.php';

// Check if user is logged in
$isLoggedIn = isset($_SESSION['user_id']);
$userId = $isLoggedIn ? $_SESSION['user_id'] : null;
$userType = $isLoggedIn ? $_SESSION['user_type'] : null;

// Initialize variables
$animals = [];
$filterType = isset($_GET['type']) ? $_GET['type'] : 'all';
$filterAge = isset($_GET['age']) ? $_GET['age'] : 'all';
$filterSize = isset($_GET['size']) ? $_GET['size'] : 'all';

// Prepare base query
$query = "SELECT * FROM animals WHERE 1=1";
$params = [];

// Add filters
if ($filterType != 'all') {
    $query .= " AND animal_type = ?";
    $params[] = $filterType;
}

if ($filterAge != 'all') {
    $query .= " AND age_group = ?";
    $params[] = $filterAge;
}

if ($filterSize != 'all') {
    $query .= " AND size = ?";
    $params[] = $filterSize;
}

// If user is logged in as a foster, show only their fostered pets
if ($isLoggedIn && $userType == 'foster') {
    $query .= " AND (foster_id = ? OR foster_id IS NULL)";
    $params[] = $userId;
}

// Prepare and execute statement
$stmt = $conn->prepare($query);

// Check if prepare was successful
if ($stmt === false) {
    die("Error preparing statement: " . $conn->error);
}

// Bind parameters dynamically
if (!empty($params)) {
    $types = str_repeat('s', count($params));
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

// Fetch all animals
while ($row = $result->fetch_assoc()) {
    $animals[] = $row;
}

// Get user's favorite animals if logged in
$favorites = [];
if ($isLoggedIn) {
    $favStmt = $conn->prepare("SELECT animal_id FROM favorites WHERE user_id = ?");
    if ($favStmt === false) {
        die("Error preparing favorites statement: " . $conn->error);
    }
    $favStmt->bind_param("i", $userId);
    $favStmt->execute();
    $favResult = $favStmt->get_result();
    
    while ($row = $favResult->fetch_assoc()) {
        $favorites[] = $row['animal_id'];
    }
    $favStmt->close();
}

// Process actions
if ($isLoggedIn && isset($_POST['action'])) {
    if ($_POST['action'] == 'favorite' && isset($_POST['animal_id'])) {
        $animalId = $_POST['animal_id'];
        
        // Check if already favorited
        $checkStmt = $conn->prepare("SELECT * FROM favorites WHERE user_id = ? AND animal_id = ?");
        if ($checkStmt === false) {
            die("Error preparing check favorites statement: " . $conn->error);
        }
        $checkStmt->bind_param("ii", $userId, $animalId);
        $checkStmt->execute();
        $checkResult = $checkStmt->get_result();
        
        if ($checkResult->num_rows == 0) {
            // Add to favorites
            $addStmt = $conn->prepare("INSERT INTO favorites (user_id, animal_id) VALUES (?, ?)");
            if ($addStmt === false) {
                die("Error preparing add favorites statement: " . $conn->error);
            }
            $addStmt->bind_param("ii", $userId, $animalId);
            $addStmt->execute();
            $addStmt->close();
            
            // Add to favorites array for the current page view
            $favorites[] = $animalId;
        } else {
            // Remove from favorites
            $removeStmt = $conn->prepare("DELETE FROM favorites WHERE user_id = ? AND animal_id = ?");
            if ($removeStmt === false) {
                die("Error preparing remove favorites statement: " . $conn->error);
            }
            $removeStmt->bind_param("ii", $userId, $animalId);
            $removeStmt->execute();
            $removeStmt->close();
            
            // Remove from favorites array for the current page view
            $key = array_search($animalId, $favorites);
            if ($key !== false) {
                unset($favorites[$key]);
            }
        }
        
        $checkStmt->close();
        
        // Redirect to avoid form resubmission
        header("Location: animals.php" . ($_SERVER['QUERY_STRING'] ? '?'.$_SERVER['QUERY_STRING'] : ''));
        exit();
    }
    
    if ($userType == 'adopter' && $_POST['action'] == 'adopt' && isset($_POST['animal_id'])) {
        $animalId = $_POST['animal_id'];
        
        // Create adoption request
        $adoptStmt = $conn->prepare("INSERT INTO adoption_requests (user_id, animal_id, request_date, status) VALUES (?, ?, NOW(), 'pending')");
        if ($adoptStmt === false) {
            die("Error preparing adoption statement: " . $conn->error);
        }
        $adoptStmt->bind_param("ii", $userId, $animalId);
        $adoptStmt->execute();
        $adoptStmt->close();
        
        // Redirect with success message
        header("Location: animals.php?adoption_requested=true");
        exit();
    }
    
    if ($userType == 'foster' && $_POST['action'] == 'foster' && isset($_POST['animal_id'])) {
        $animalId = $_POST['animal_id'];
        
        // Create foster request in adoption_requests table
        $fosterStmt = $conn->prepare("INSERT INTO adoption_requests (user_id, animal_id, request_date, status, notes) VALUES (?, ?, NOW(), 'pending', 'Foster request')");
        if ($fosterStmt === false) {
            die("Error preparing foster request statement: " . $conn->error);
        }
        $fosterStmt->bind_param("ii", $userId, $animalId);
        $fosterStmt->execute();
        $fosterStmt->close();
        
        // Update animal to be fostered by this user (optional - depends on your business logic)
        // You may want to keep this commented out if you want admin approval first
        // $updateStmt = $conn->prepare("UPDATE animals SET foster_id = ? WHERE id = ? AND foster_id IS NULL");
        // if ($updateStmt === false) {
        //     die("Error preparing animal update statement: " . $conn->error);
        // }
        // $updateStmt->bind_param("ii", $userId, $animalId);
        // $updateStmt->execute();
        // $updateStmt->close();
        
        // Redirect with success message
        header("Location: animals.php?foster_requested=true");
        exit();
    }
}

// Close the database connection
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Available Animals - Paws & Hearts</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* Base Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f9f9f9;
            color: #333;
        }

        a {
            color: #e07a5f;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        .container {
            width: 90%;
            max-width: 1200px;
            margin: auto;
        }

        /* Header */
        header {
            background-color: #fff;
            padding: 20px 0;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo h1 {
            font-size: 1.8rem;
            color: #e07a5f;
        }

        .nav-links {
            list-style: none;
            display: flex;
            gap: 20px;
        }

        .nav-links li a {
            padding: 8px 12px;
            border-radius: 5px;
            font-weight: 500;
        }

        .nav-links li a:hover,
        .nav-links li a.active {
            background-color: #e07a5f;
            color: white;
        }

        .burger {
            display: none;
            font-size: 24px;
            cursor: pointer;
        }

        /* Banner */
        .banner {
            background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('https://images.unsplash.com/photo-1587300003388-59208cc962cb?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80');
            background-size: cover;
            background-position: center;
            color: white;
            text-align: center;
            padding: 80px 0;
        }

        .banner h2 {
            font-size: 2.5rem;
            margin-bottom: 20px;
        }

        .banner p {
            font-size: 1.2rem;
            max-width: 800px;
            margin: 0 auto 30px;
        }

        /* Filter Section */
        .filter-section {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            margin: -30px auto 30px;
            max-width: 1000px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            position: relative;
        }

        .filter-form {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            justify-content: center;
        }

        .filter-group {
            flex: 1;
            min-width: 150px;
        }

        .filter-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
        }

        .filter-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: #f9f9f9;
        }

        .filter-button {
            display: flex;
            align-items: flex-end;
        }

        .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #e07a5f;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        .btn:hover {
            background-color: #cf6143;
        }

        /* Animals Grid */
        .animals-section {
            padding: 30px 0;
        }

        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border: 1px solid transparent;
            border-radius: 5px;
            text-align: center;
            color: #155724;
            background-color: #d4edda;
            border-color: #c3e6cb;
        }

        .animals-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 30px;
        }

        .animal-card {
            background-color: #fff;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }

        .animal-card:hover {
            transform: translateY(-5px);
        }

        .animal-image {
            height: 200px;
            overflow: hidden;
            position: relative;
        }

        .animal-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .favorite-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            background-color: rgba(255, 255, 255, 0.8);
            width: 36px;
            height: 36px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            border: none;
            font-size: 18px;
            color: #ccc;
        }

        .favorite-btn.active {
            color: #e74c3c;
        }

        .animal-info {
            padding: 20px;
        }

        .animal-name {
            font-size: 1.5rem;
            margin-bottom: 5px;
            color: #333;
        }

        .animal-breed {
            color: #666;
            margin-bottom: 10px;
        }

        .animal-description {
            margin-bottom: 15px;
            line-height: 1.5;
        }

        .animal-details {
            display: flex;
            gap: 15px;
            margin-bottom: 15px;
        }

        .detail {
            display: flex;
            align-items: center;
            gap: 5px;
            color: #666;
        }

        .detail i {
            color: #e07a5f;
        }

        .animal-actions {
            display: flex;
            gap: 10px;
        }

        .btn-outline {
            background-color: transparent;
            border: 1px solid #e07a5f;
            color: #e07a5f;
        }

        .btn-outline:hover {
            background-color: #e07a5f;
            color: white;
        }

        /* Footer */
        footer {
            background-color: #f1f1f1;
            padding: 20px 0;
            text-align: center;
            font-size: 0.9rem;
            color: #666;
            margin-top: 40px;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .nav-links {
                display: none;
            }

            .burger {
                display: block;
            }

            .filter-form {
                flex-direction: column;
            }

            .animals-grid {
                grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            }
        }

        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 30px;
            gap: 5px;
        }

        .pagination a {
            display: inline-block;
            padding: 8px 15px;
            background-color: #f1f1f1;
            border-radius: 5px;
            color: #333;
        }

        .pagination a.active {
            background-color: #e07a5f;
            color: white;
        }

        .no-animals {
            text-align: center;
            padding: 40px 0;
            font-size: 1.2rem;
            color: #666;
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <nav>
                <div class="logo">
                    <h1><i class="fas fa-paw"></i> Paws & Hearts</h1>
                </div>
                <ul class="nav-links">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="animals.php" class="active">Animals</a></li>
                    <li><a href="about.html">About</a></li>
                    <li><a href="contact.html">Contact</a></li>
                    <?php if ($isLoggedIn): ?>
                        <li><a href="dashboard.php">My Profile</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    <?php else: ?>
                        <li><a href="login.php">Login</a></li>
                        <li><a href="register.php" class="btn">Register</a></li>
                    <?php endif; ?>
                </ul>
                <div class="burger">
                    <i class="fas fa-bars"></i>
                </div>
            </nav>
        </div>
    </header>

    <section class="banner">
        <div class="container">
            <h2>Find Your Perfect Companion</h2>
            <p>Browse our directory of lovable pets waiting for their forever homes.</p>
        </div>
    </section>

    <section class="filter-section">
        <div class="container">
            <form action="animals.php" method="GET" class="filter-form">
                <div class="filter-group">
                    <label for="type">Animal Type</label>
                    <select name="type" id="type">
                        <option value="all" <?php echo $filterType == 'all' ? 'selected' : ''; ?>>All Types</option>
                        <option value="dog" <?php echo $filterType == 'dog' ? 'selected' : ''; ?>>Dogs</option>
                        <option value="cat" <?php echo $filterType == 'cat' ? 'selected' : ''; ?>>Cats</option>
                        <option value="bird" <?php echo $filterType == 'bird' ? 'selected' : ''; ?>>Birds</option>
                        <option value="small_animal" <?php echo $filterType == 'small_animal' ? 'selected' : ''; ?>>Small Animals</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label for="age">Age</label>
                    <select name="age" id="age">
                        <option value="all" <?php echo $filterAge == 'all' ? 'selected' : ''; ?>>All Ages</option>
                        <option value="baby" <?php echo $filterAge == 'baby' ? 'selected' : ''; ?>>Baby</option>
                        <option value="young" <?php echo $filterAge == 'young' ? 'selected' : ''; ?>>Young</option>
                        <option value="adult" <?php echo $filterAge == 'adult' ? 'selected' : ''; ?>>Adult</option>
                        <option value="senior" <?php echo $filterAge == 'senior' ? 'selected' : ''; ?>>Senior</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label for="size">Size</label>
                    <select name="size" id="size">
                        <option value="all" <?php echo $filterSize == 'all' ? 'selected' : ''; ?>>All Sizes</option>
                        <option value="small" <?php echo $filterSize == 'small' ? 'selected' : ''; ?>>Small</option>
                        <option value="medium" <?php echo $filterSize == 'medium' ? 'selected' : ''; ?>>Medium</option>
                        <option value="large" <?php echo $filterSize == 'large' ? 'selected' : ''; ?>>Large</option>
                    </select>
                </div>
                <div class="filter-button">
                    <button type="submit" class="btn">Filter</button>
                </div>
            </form>
        </div>
    </section>

    <section class="animals-section">
        <div class="container">
            <?php if (isset($_GET['adoption_requested']) && $_GET['adoption_requested'] == 'true'): ?>
                <div class="alert">
                    <p>Your adoption request has been submitted! Our team will contact you soon.</p>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_GET['foster_requested']) && $_GET['foster_requested'] == 'true'): ?>
                <div class="alert">
                    <p>Thank you for offering to foster! Our team will contact you with next steps.</p>
                </div>
            <?php endif; ?>
            
            <?php if (empty($animals)): ?>
                <div class="no-animals">
                    <p>No animals found matching your criteria. Please try different filters.</p>
                </div>
            <?php else: ?>
                <div class="animals-grid">
                    <?php foreach ($animals as $animal): ?>
                        <div class="animal-card">
                            <div class="animal-image">
                                <img src="<?php echo htmlspecialchars($animal['image_url']); ?>" alt="<?php echo htmlspecialchars($animal['name']); ?>">
                                <?php if ($isLoggedIn): ?>
                                    <form method="post">
                                        <input type="hidden" name="action" value="favorite">
                                        <input type="hidden" name="animal_id" value="<?php echo $animal['id']; ?>">
                                        <button type="submit" class="favorite-btn <?php echo in_array($animal['id'], $favorites) ? 'active' : ''; ?>">
                                            <i class="fas fa-heart"></i>
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </div>
                            <div class="animal-info">
                                <h3 class="animal-name"><?php echo htmlspecialchars($animal['name']); ?></h3>
                                <p class="animal-breed"><?php echo htmlspecialchars($animal['breed']); ?></p>
                                <p class="animal-description"><?php echo htmlspecialchars($animal['description']); ?></p>
                                <div class="animal-details">
                                    <div class="detail">
                                        <i class="fas fa-birthday-cake"></i>
                                        <span><?php echo htmlspecialchars($animal['age_group']); ?></span>
                                    </div>
                                    <div class="detail">
                                        <i class="fas fa-weight"></i>
                                        <span><?php echo htmlspecialchars($animal['size']); ?></span>
                                    </div>
                                    <div class="detail">
                                        <i class="fas fa-venus-mars"></i>
                                        <span><?php echo htmlspecialchars($animal['gender']); ?></span>
                                    </div>
                                </div>
                                <div class="animal-actions">
                                    <a href="animal_details.php?id=<?php echo $animal['id']; ?>" class="btn btn-outline">More Info</a>
                                    
                                    <?php if ($isLoggedIn): ?>
                                        <?php if ($userType == 'adopter' && $animal['status'] == 'available'): ?>
                                            <form method="post" onsubmit="return confirm('Are you sure you want to submit an adoption request for <?php echo htmlspecialchars($animal['name']); ?>?');">
                                                <input type="hidden" name="action" value="adopt">
                                                <input type="hidden" name="animal_id" value="<?php echo $animal['id']; ?>">
                                                <button type="submit" class="btn">Adopt Me</button>
                                            </form>
                                        <?php elseif ($userType == 'foster' && $animal['foster_id'] == null): ?>
                                            <form method="post" onsubmit="return confirm('Are you sure you want to foster <?php echo htmlspecialchars($animal['name']); ?>?');">
                                                <input type="hidden" name="action" value="foster">
                                                <input type="hidden" name="animal_id" value="<?php echo $animal['id']; ?>">
                                                <button type="submit" class="btn">Foster Me</button>
                                            </form>
                                        <?php elseif ($userType == 'foster' && $animal['foster_id'] == $userId): ?>
                                            <span class="btn btn-outline">Currently Fostering</span>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <a href="login.php" class="btn">Login to Adopt</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            
            <!-- Pagination example - to be implemented based on total records -->
            <div class="pagination">
                <a href="#" class="active">1</a>
                <a href="#">2</a>
                <a href="#">3</a>
                <a href="#">Next</a>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> Paws & Hearts Animal Adoption. All rights reserved.</p>
        </div>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Toggle navigation menu for mobile
            const burger = document.querySelector('.burger');
            const nav = document.querySelector('.nav-links');
            
            if(burger) {
                burger.addEventListener('click', function() {
                    nav.style.display = nav.style.display === 'flex' ? 'none' : 'flex';
                });
            }
            
            // Check if any "More Info" buttons exist and ensure they're properly functioning
            const moreInfoLinks = document.querySelectorAll('.animal-actions .btn-outline');
            moreInfoLinks.forEach(link => {
                link.addEventListener('click', function(e) {
                    // You can add click tracking or other logic here if needed
                    // This is just to ensure the links are properly set up with event listeners
                    console.log('Navigating to animal details page');
                });
            });
        });
    </script>
</body>
</html>