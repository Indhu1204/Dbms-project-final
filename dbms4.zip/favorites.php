<?php
session_start();
require 'db.php'; // Assumes you have a DB connection file

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch user's favorite animals
$sql = "SELECT a.id, a.name, a.breed, a.animal_type, a.image_url, a.age_group, a.gender 
        FROM favorites f
        JOIN animals a ON f.animal_id = a.id
        WHERE f.user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Favorites</title>
    <style>
        .animal-card {
            border: 1px solid #ccc;
            border-radius: 10px;
            padding: 10px;
            margin: 10px;
            display: inline-block;
            width: 200px;
            text-align: center;
        }
        .animal-card img {
            width: 100%;
            height: 150px;
            object-fit: cover;
            border-radius: 8px;
        }
    </style>
</head>
<body>
    <h2>Your Favorite Animals</h2>
    <div class="animal-list">
        <?php
        if ($result->num_rows > 0) {
            while ($animal = $result->fetch_assoc()) {
                echo '<div class="animal-card">';
                echo '<img src="' . htmlspecialchars($animal['image_url']) . '" alt="' . htmlspecialchars($animal['name']) . '">';
                echo '<h4>' . htmlspecialchars($animal['name']) . '</h4>';
                echo '<p>Type: ' . htmlspecialchars($animal['animal_type']) . '</p>';
                echo '<p>Breed: ' . htmlspecialchars($animal['breed']) . '</p>';
                echo '<p>Age: ' . htmlspecialchars($animal['age_group']) . '</p>';
                echo '<p>Gender: ' . htmlspecialchars($animal['gender']) . '</p>';
                echo '</div>';
            }
        } else {
            echo "<p>You haven't added any favorites yet.</p>";
        }
        ?>
    </div>
</body>
</html>