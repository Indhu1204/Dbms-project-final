<?php
// Include database connection
require_once 'db.php';

// Initialize variables
$errors = [];
$success = false;

// Process form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize input
    $firstName = trim($_POST['firstName']);
    $lastName = trim($_POST['lastName']);
    $email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);
    $password = trim($_POST['password']);
    $confirmPassword = trim($_POST['confirmPassword']);
    $userType = trim($_POST['userType']);
    
    // Perform validation
    if (empty($firstName)) {
        $errors[] = "First name is required";
    }
    
    if (empty($lastName)) {
        $errors[] = "Last name is required";
    }
    
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Valid email is required";
    } else {
        // Check if email already exists
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $errors[] = "Email already exists. Please use a different email or login.";
        }
        $stmt->close();
    }
    
    if (empty($phone)) {
        $errors[] = "Phone number is required";
    }
    
    if (empty($address)) {
        $errors[] = "Address is required";
    }
    
    if (empty($password)) {
        $errors[] = "Password is required";
    } elseif (strlen($password) < 8) {
        $errors[] = "Password must be at least 8 characters long";
    }
    
    if ($password !== $confirmPassword) {
        $errors[] = "Passwords do not match";
    }
    
    if (!isset($_POST['terms'])) {
        $errors[] = "You must agree to the Terms of Service and Privacy Policy";
    }
    
    // If no errors, insert user into database
    if (empty($errors)) {
        // Hash password for security
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        
        // Prepare statement to prevent SQL injection
        $stmt = $conn->prepare("INSERT INTO users (first_name, last_name, email, phone, address, password, user_type) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssss", $firstName, $lastName, $email, $phone, $address, $hashedPassword, $userType);
        
        if ($stmt->execute()) {
            $success = true;
            
            // Automatically log the user in (set session)
            session_start();
            $_SESSION['user_id'] = $stmt->insert_id;
            $_SESSION['first_name'] = $firstName;
            $_SESSION['last_name'] = $lastName;
            $_SESSION['email'] = $email;
            $_SESSION['user_type'] = $userType;
            
            // Redirect to home page after successful registration
            header("Location: home.php");
            exit();
        } else {
            $errors[] = "Registration failed: " . $conn->error;
        }
        
        $stmt->close();
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Paws & Hearts</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<style>
    /* Base Reset */
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background-color: #f9f9f9;
        color: #333;
    }

    a {
        color: #e07a5f;
        text-decoration: none;
    }

    a:hover {
        text-decoration: underline;
    }

    .container {
        width: 90%;
        max-width: 1200px;
        margin: auto;
    }

    /* Header */
    header {
        background-color: #fff;
        padding: 20px 0;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }

    nav {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .logo h1 {
        font-size: 1.8rem;
        color: #e07a5f;
    }

    .nav-links {
        list-style: none;
        display: flex;
        gap: 20px;
    }

    .nav-links li a {
        padding: 8px 12px;
        border-radius: 5px;
        font-weight: 500;
    }

    .nav-links li a:hover,
    .nav-links li a.btn {
        background-color: #e07a5f;
        color: white;
    }

    .burger {
        display: none;
        font-size: 24px;
        cursor: pointer;
    }

    /* Auth Section */
    .auth-section {
        padding: 60px 0;
        background-color: #fff;
    }

    .auth-container {
        display: flex;
        flex-wrap: wrap;
        gap: 40px;
        align-items: flex-start;
        justify-content: center;
    }

    .auth-image img {
        max-width: 400px;
        width: 100%;
        border-radius: 10px;
    }

    .auth-form {
        max-width: 600px;
        width: 100%;
        background: #fefefe;
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0 0 15px rgba(0,0,0,0.05);
    }

    .auth-form h2 {
        color: #e07a5f;
        margin-bottom: 10px;
    }

    .auth-form p {
        margin-bottom: 20px;
    }

    .form-group {
        margin-bottom: 15px;
        position: relative;
    }

    .form-group label {
        display: block;
        margin-bottom: 5px;
    }

    .form-group input,
    .form-group select {
        width: 100%;
        padding: 10px 35px 10px 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }

    .form-group i {
        position: absolute;
        top: 50%;
        right: 10px;
        transform: translateY(-50%);
        color: #888;
    }

    .form-row {
        display: flex;
        gap: 15px;
    }

    .form-row .form-group {
        flex: 1;
    }

    .form-group.terms {
        display: flex;
        align-items: center;
        font-size: 0.9rem;
    }

    .form-group.terms input[type="checkbox"] {
        margin-right: 10px;
    }

    .btn {
        display: inline-block;
        padding: 10px 20px;
        background-color: #e07a5f;
        color: #fff;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        transition: background 0.3s ease;
    }

    .btn:hover {
        background-color: #cf6143;
    }

    .btn-block {
        width: 100%;
        text-align: center;
    }

    .auth-alternative {
        text-align: center;
        margin-top: 15px;
    }

    footer {
        background-color: #f1f1f1;
        padding: 20px 0;
        text-align: center;
        font-size: 0.9rem;
        color: #666;
        margin-top: 40px;
    }

    /* Responsive */
    @media (max-width: 768px) {
        .auth-container {
            flex-direction: column;
            text-align: center;
        }

        .form-row {
            flex-direction: column;
        }

        .nav-links {
            display: none;
        }

        .burger {
            display: block;
        }
    }
    
    /* Error messages */
    .alert {
        padding: 15px;
        margin-bottom: 20px;
        border: 1px solid transparent;
        border-radius: 5px;
    }
    
    .alert-danger {
        color: #721c24;
        background-color: #f8d7da;
        border-color: #f5c6cb;
    }
    
    .alert-success {
        color: #155724;
        background-color: #d4edda;
        border-color: #c3e6cb;
    }
</style>
</head>
<body>
    <header>
        <div class="container">
            <nav>
                <div class="logo">
                    <h1><i class="fas fa-paw"></i> Paws & Hearts</h1>
                </div>
                <ul class="nav-links">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="animals.html">Animals</a></li>
                    <li><a href="about.html">About</a></li>
                    <li><a href="contact.html">Contact</a></li>
                    <li><a href="login.php" class="btn">Login</a></li>
                </ul>
                <div class="burger">
                    <i class="fas fa-bars"></i>
                </div>
            </nav>
        </div>
    </header>

    <section class="auth-section">
        <div class="container">
            <div class="auth-container">
                <div class="auth-image">
                    <img src="https://images.unsplash.com/photo-1530281700549-e82e7bf110d6?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80" alt="Happy cat">
                </div>
                <div class="auth-form">
                    <h2>Create Your Account</h2>
                    <p>Join our community to start your adoption journey today.</p>
                    
                    <?php if (!empty($errors)): ?>
                        <div class="alert alert-danger">
                            <?php foreach ($errors as $error): ?>
                                <p><?php echo $error; ?></p>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($success): ?>
                        <div class="alert alert-success">
                            <p>Registration successful! Redirecting to home page...</p>
                        </div>
                    <?php endif; ?>
                    
                    <form id="registerForm" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="firstName">First Name</label>
                                <input type="text" id="firstName" name="firstName" required value="<?php echo isset($firstName) ? htmlspecialchars($firstName) : ''; ?>">
                                <i class="fas fa-user"></i>
                            </div>
                            <div class="form-group">
                                <label for="lastName">Last Name</label>
                                <input type="text" id="lastName" name="lastName" required value="<?php echo isset($lastName) ? htmlspecialchars($lastName) : ''; ?>">
                                <i class="fas fa-user"></i>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" id="email" name="email" required value="<?php echo isset($email) ? htmlspecialchars($email) : ''; ?>">
                            <i class="fas fa-envelope"></i>
                        </div>
                        <div class="form-group">
                            <label for="phone">Phone Number</label>
                            <input type="tel" id="phone" name="phone" required value="<?php echo isset($phone) ? htmlspecialchars($phone) : ''; ?>">
                            <i class="fas fa-phone"></i>
                        </div>
                        <div class="form-group">
                            <label for="address">Address</label>
                            <input type="text" id="address" name="address" required value="<?php echo isset($address) ? htmlspecialchars($address) : ''; ?>">
                            <i class="fas fa-home"></i>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label for="password">Password</label>
                                <input type="password" id="password" name="password" required>
                                <i class="fas fa-lock"></i>
                            </div>
                            <div class="form-group">
                                <label for="confirmPassword">Confirm Password</label>
                                <input type="password" id="confirmPassword" name="confirmPassword" required>
                                <i class="fas fa-lock"></i>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="userType">I want to:</label>
                            <select id="userType" name="userType">
                                <option value="adopter" <?php echo (isset($userType) && $userType == 'adopter') ? 'selected' : ''; ?>>Adopt a pet</option>
                                <option value="volunteer" <?php echo (isset($userType) && $userType == 'volunteer') ? 'selected' : ''; ?>>Volunteer</option>
                                <option value="foster" <?php echo (isset($userType) && $userType == 'foster') ? 'selected' : ''; ?>>Foster pets</option>
                            </select>
                        </div>
                        <div class="form-group terms">
                            <input type="checkbox" id="terms" name="terms" required>
                            <label for="terms">I agree to the <a href="#">Terms of Service</a> and <a href="#">Privacy Policy</a></label>
                        </div>
                        <button type="submit" class="btn btn-primary btn-block">Register</button>
                        <div class="auth-alternative">
                            <p>Already have an account? <a href="login.php">Login here</a></p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <p>&copy; 2023 Paws & Hearts Animal Adoption. All rights reserved.</p>
        </div>
    </footer>

    <script src="js/main.js"></script>
</body>
</html>