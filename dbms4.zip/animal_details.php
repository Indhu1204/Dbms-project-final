<?php
// At the top of animal_details.php, add this code to get the animal ID from URL
// and fetch animal data from database
session_start();
require 'db.php';

// Get animal ID from URL
$animal_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Fetch animal details from database
if ($animal_id > 0) {
    $sql = "SELECT * FROM animals WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $animal_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $animal = $result->fetch_assoc();
    
    // If animal not found, redirect to animals page
    if (!$animal) {
        header("Location: animals.php");
        exit();
    }
} else {
    header("Location: animals.php");
    exit();
}

// Now you have $animal with all data from the database
// You can use $animal['id'], $animal['name'], etc. throughout your page
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buddy - Paws & Hearts</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<style>
    /* Reset & Base Styles */
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }
    body {
        font-family: Arial, sans-serif;
        line-height: 1.6;
        background-color: #f8f9fa;
        color: #333;
    }
    a {
        text-decoration: none;
        color: #007bff;
    }
    ul {
        list-style: none;
    }

    /* Header */
    header {
        background: #fff;
        border-bottom: 1px solid #ddd;
        padding: 10px 0;
    }
    nav {
        display: flex;
        justify-content: space-between;
        align-items: center;
        max-width: 1200px;
        margin: auto;
        padding: 0 20px;
    }
    .logo h1 {
        font-size: 24px;
        color: #ff6b6b;
    }
    .nav-links {
        display: flex;
        gap: 20px;
        align-items: center;
    }
    .nav-links a.btn {
        padding: 6px 14px;
        background-color: #ff6b6b;
        color: #fff;
        border-radius: 4px;
    }

    /* Animal Detail */
    .animal-detail {
        padding: 40px 20px;
    }
    .container {
        max-width: 1200px;
        margin: auto;
    }
    .breadcrumbs {
        margin-bottom: 20px;
        font-size: 14px;
    }
    .animal-detail-container {
        display: flex;
        flex-wrap: wrap;
        gap: 40px;
    }

    .animal-gallery {
        flex: 1;
        min-width: 300px;
    }
    .main-image img {
        width: 100%;
        border-radius: 8px;
    }
    .thumbnail-images {
        margin-top: 10px;
        display: flex;
        gap: 10px;
    }
    .thumbnail {
        width: 60px;
        height: 60px;
        object-fit: cover;
        border-radius: 4px;
        cursor: pointer;
        border: 2px solid transparent;
    }
    .thumbnail.active {
        border-color: #ff6b6b;
    }

    .animal-info {
        flex: 1;
        min-width: 300px;
    }
    .animal-info h1 {
        font-size: 32px;
        margin-bottom: 10px;
    }
    .animal-meta {
        margin-bottom: 20px;
    }
    .animal-id {
        display: inline-block;
        margin-right: 20px;
        font-weight: bold;
    }
    .animal-status {
        padding: 4px 10px;
        border-radius: 4px;
        background: #28a745;
        color: #fff;
        font-size: 14px;
    }

    .animal-details .detail-row {
        display: flex;
        margin-bottom: 10px;
    }
    .detail-label {
        width: 100px;
        font-weight: bold;
    }

    .animal-description {
        margin-top: 20px;
    }
    .animal-actions {
        margin-top: 20px;
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
    }
    .btn {
        padding: 10px 16px;
        border: none;
        cursor: pointer;
        border-radius: 4px;
        font-weight: bold;
    }
    .btn-primary {
        background: #ff6b6b;
        color: white;
    }
    .btn-secondary {
        background: #6c757d;
        color: white;
    }
    .btn-outline {
        background: transparent;
        border: 2px solid #6c757d;
        color: #6c757d;
    }

    /* Tabs */
    .animal-tabs {
        margin-top: 40px;
    }
    .tab-nav {
        display: flex;
        gap: 20px;
        border-bottom: 2px solid #ddd;
        margin-bottom: 20px;
    }
    .tab-nav li a {
        padding: 10px 0;
        display: inline-block;
        font-weight: bold;
        color: #333;
    }
    .tab-nav li.active a {
        border-bottom: 3px solid #ff6b6b;
        color: #ff6b6b;
    }
    .tab-content {
        display: none;
    }
    .tab-content.active {
        display: block;
    }

    /* Sections inside Tabs */
    .health-details,
    .behavior-details,
    .requirements-list {
        display: flex;
        flex-wrap: wrap;
        gap: 30px;
    }
    .health-status,
    .behavior-traits,
    .behavior-notes,
    .requirement {
        flex: 1;
        min-width: 250px;
    }
    .traits-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
        gap: 10px;
    }
    .trait-rating i {
        color: #ff6b6b;
    }

    .adoption-process {
        margin-top: 20px;
    }

    /* Similar Animals */
    .similar-animals {
        margin-top: 60px;
    }
    .animals-grid.mini-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
        gap: 20px;
    }

    /* Footer */
    footer {
        background: #333;
        color: #fff;
        text-align: center;
        padding: 20px 0;
        margin-top: 40px;
    }

    /* Responsive */
    @media (max-width: 768px) {
        .animal-detail-container {
            flex-direction: column;
        }
        .tab-nav {
            flex-direction: column;
        }
    }
</style>
</head>
<body>
    <header>
        <div class="container">
            <nav>
                <div class="logo">
                    <h1><i class="fas fa-paw"></i> Paws & Hearts</h1>
                </div>
                <ul class="nav-links">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="animals.php">Animals</a></li>
                    <li><a href="about.html">About</a></li>
                    <li><a href="contact.html">Contact</a></li>
                    <li><a href="login.php" class="btn">Login</a></li>
                </ul>
                <div class="burger">
                    <i class="fas fa-bars"></i>
                </div>
            </nav>
        </div>
    </header>

    <section class="animal-detail">
        <div class="container">
            <div class="breadcrumbs">
                <a href="home.php">Home</a> / <a href="animals.php">Animals</a> / <span>Buddy</span>
            </div>
            
            <div class="animal-detail-container">
                <div class="animal-gallery">
                    <div class="main-image">
                        <img src="https://images.unsplash.com/photo-1561037404-61cd46aa615b?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" alt="Buddy" id="mainImage">
                    </div>
                    <div class="thumbnail-images">
                        <img src="https://images.unsplash.com/photo-1561037404-61cd46aa615b?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80" alt="Buddy" class="thumbnail active">
                        <img src="https://images.unsplash.com/photo-1586671267731-da2cf3ceeb80?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80" alt="Buddy playing" class="thumbnail">
                        <img src="https://images.unsplash.com/photo-1588943211346-0908a1fb0b01?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80" alt="Buddy sleeping" class="thumbnail">
                        <img src="https://images.unsplash.com/photo-1586671267731-da2cf3ceeb80?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80" alt="Buddy with toy" class="thumbnail">
                    </div>
                </div>
                
                <div class="animal-info">
                    <h1>Buddy</h1>
                    <div class="animal-meta">
                        <span class="animal-id">ID: PAWS-2456</span>
                        <span class="animal-status available">Available</span>
                    </div>
                    
                    <div class="animal-details">
                        <div class="detail-row">
                            <span class="detail-label">Breed:</span>
                            <span class="detail-value">Golden Retriever</span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">Age:</span>
                            <span class="detail-value">2 years</span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">Gender:</span>
                            <span class="detail-value">Male</span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">Size:</span>
                            <span class="detail-value">Large</span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">Color:</span>
                            <span class="detail-value">Golden</span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">Location:</span>
                            <span class="detail-value">Main Shelter</span>
                        </div>
                    </div>
                    
                    <div class="animal-description">
                        <h3>About Buddy</h3>
                        <p>Buddy is a sweet and gentle Golden Retriever who loves everyone he meets. He was surrendered to our shelter when his previous owners could no longer care for him. Buddy is house-trained, knows basic commands, and walks well on a leash. He's great with kids and other dogs, and would make a wonderful addition to any active family.</p>
                        <p>Buddy enjoys long walks, playing fetch, and cuddling on the couch. He has a calm demeanor but also loves to play. He would do best in a home with a yard where he can run around, but he also adapts well to apartment living as long as he gets plenty of exercise.</p>
                    </div>
                    
                    <div class="animal-actions">
                        <a href="add_to_favorites.php?animal_id=<?php echo $animal_id; ?>" class="btn btn-primary"><i class="fas fa-heart"></i> Add to Favorites</a>
                        <button class="btn btn-secondary"><i class="fas fa-file-alt"></i> Apply to Adopt</button>
                        <button class="btn btn-outline"><i class="fas fa-share-alt"></i> Share</button>
                    </div>
                </div>
            </div>
            
            <div class="animal-tabs">
                <ul class="tab-nav">
                    <li class="active"><a href="#health" data-tab="health">Health Information</a></li>
                    <li><a href="#behavior" data-tab="behavior">Behavior & Training</a></li>
                    <li><a href="#history" data-tab="history">History</a></li>
                    <li><a href="#requirements" data-tab="requirements">Adoption Requirements</a></li>
                </ul>
                
                <div class="tab-content active" id="health">
                    <h3>Health Information</h3>
                    <div class="health-details">
                        <div class="health-status">
                            <h4>Vaccination Status</h4>
                            <ul>
                                <li><i class="fas fa-check-circle success"></i> Rabies</li>
                                <li><i class="fas fa-check-circle success"></i> Distemper</li>
                                <li><i class="fas fa-check-circle success"></i> Parvovirus</li>
                                <li><i class="fas fa-check-circle success"></i> Bordetella</li>
                            </ul>
                        </div>
                        <div class="health-status">
                            <h4>Medical Notes</h4>
                            <ul>
                                <li>Neutered</li>
                                <li>Microchipped</li>
                                <li>No known health issues</li>
                                <li>Current on flea/tick/heartworm prevention</li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <div class="tab-content" id="behavior">
                    <h3>Behavior & Training</h3>
                    <div class="behavior-details">
                        <div class="behavior-traits">
                            <h4>Personality Traits</h4>
                            <div class="traits-grid">
                                <div class="trait">
                                    <span class="trait-name">Energy Level</span>
                                    <div class="trait-rating">
                                        <i class="fas fa-circle"></i>
                                        <i class="fas fa-circle"></i>
                                        <i class="fas fa-circle"></i>
                                        <i class="fas fa-circle"></i>
                                        <i class="far fa-circle"></i>
                                    </div>
                                </div>
                                <div class="trait">
                                    <span class="trait-name">Friendliness</span>
                                    <div class="trait-rating">
                                        <i class="fas fa-circle"></i>
                                        <i class="fas fa-circle"></i>
                                        <i class="fas fa-circle"></i>
                                        <i class="fas fa-circle"></i>
                                        <i class="fas fa-circle"></i>
                                    </div>
                                </div>
                                <div class="trait">
                                    <span class="trait-name">Trainability</span>
                                    <div class="trait-rating">
                                        <i class="fas fa-circle"></i>
                                        <i class="fas fa-circle"></i>
                                        <i class="fas fa-circle"></i>
                                        <i class="fas fa-circle"></i>
                                        <i class="far fa-circle"></i>
                                    </div>
                                </div>
                                <div class="trait">
                                    <span class="trait-name">Playfulness</span>
                                    <div class="trait-rating">
                                        <i class="fas fa-circle"></i>
                                        <i class="fas fa-circle"></i>
                                        <i class="fas fa-circle"></i>
                                        <i class="fas fa-circle"></i>
                                        <i class="fas fa-circle"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="behavior-notes">
                            <h4>Training & Behavior Notes</h4>
                            <ul>
                                <li>Knows basic commands: Sit, Stay, Come</li>
                                <li>Walks well on leash</li>
                                <li>House-trained</li>
                                <li>Good with children of all ages</li>
                                <li>Gets along with other dogs</li>
                                <li>Not tested with cats</li>
                                <li>Mild separation anxiety - does best when left with a toy</li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <div class="tab-content" id="history">
                    <h3>History</h3>
                    <p>Buddy was surrendered to our shelter in March 2023 when his previous owners moved to an apartment that didn't allow pets. He lived with them since he was a puppy and was well cared for. Buddy has no known history of abuse or neglect.</p>
                    <p>Since arriving at our shelter, Buddy has been a favorite among staff and volunteers. He participates in our "Doggy Day Out" program where volunteers take shelter dogs on outings, and he always receives glowing reviews from his temporary hosts.</p>
                </div>
                
                <div class="tab-content" id="requirements">
                    <h3>Adoption Requirements</h3>
                    <div class="requirements-list">
                        <div class="requirement">
                            <i class="fas fa-home"></i>
                            <h4>Suitable Home</h4>
                            <p>Buddy would do best in a home with a yard, though apartment living is possible with sufficient exercise.</p>
                        </div>
                        <div class="requirement">
                            <i class="fas fa-clock"></i>
                            <h4>Time Commitment</h4>
                            <p>Buddy needs an owner who can provide daily exercise and attention. He shouldn't be left alone for extended periods.</p>
                        </div>
                        <div class="requirement">
                            <i class="fas fa-users"></i>
                            <h4>Family Situation</h4>
                            <p>Buddy is great with families, singles, or couples. He's gentle with children but may accidentally knock over very small kids.</p>
                        </div>
                        <div class="requirement">
                            <i class="fas fa-heart"></i>
                            <h4>Adoption Fee</h4>
                            <p>$250 which includes neuter, microchip, vaccinations, and a free vet check within 14 days of adoption.</p>
                        </div>
                    </div>
                    <div class="adoption-process">
                        <h4>Adoption Process</h4>
                        <ol>
                            <li>Submit an adoption application</li>
                            <li>Meet with an adoption counselor</li>
                            <li>Schedule a meet-and-greet with Buddy</li>
                            <li>Home visit (for renters, we'll need landlord approval)</li>
                            <li>Finalize adoption paperwork and pay fee</li>
                            <li>Take Buddy home!</li>
                        </ol>
                        <div class="text-center">
                            <button class="btn btn-primary btn-lg"><i class="fas fa-file-alt"></i> Begin Adoption Application</button>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="similar-animals">
                <h2>You Might Also Like</h2>
                <div class="animals-grid mini-grid">
                    <!-- Dynamically loaded from animals.js -->
                </div>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <p>&copy; 2023 Paws & Hearts Animal Adoption. All rights reserved.</p>
        </div>
    </footer>

    <script>
    // JavaScript to handle tab functionality
    document.addEventListener('DOMContentLoaded', function() {
        // Tab functionality
        const tabLinks = document.querySelectorAll('.tab-nav a');
        tabLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                
                // Hide all tab contents
                const tabContents = document.querySelectorAll('.tab-content');
                tabContents.forEach(content => {
                    content.classList.remove('active');
                });
                
                // Remove active class from all tab links
                tabLinks.forEach(tabLink => {
                    tabLink.parentElement.classList.remove('active');
                });
                
                // Show the selected tab content
                const tabId = this.getAttribute('data-tab');
                document.getElementById(tabId).classList.add('active');
                
                // Add active class to the clicked tab link
                this.parentElement.classList.add('active');
            });
        });
        
        // Thumbnail image gallery
        const thumbnails = document.querySelectorAll('.thumbnail');
        const mainImage = document.getElementById('mainImage');
        
        thumbnails.forEach(thumbnail => {
            thumbnail.addEventListener('click', function() {
                // Update main image
                mainImage.src = this.src.replace('w=200', 'w=800');
                
                // Update active thumbnail
                thumbnails.forEach(thumb => {
                    thumb.classList.remove('active');
                });
                this.classList.add('active');
            });
        });
        
        // Load similar animals from JS
        loadSimilarAnimals();
    });
    
    function loadSimilarAnimals() {
        // Example similar animals (would normally be loaded from animals.js)
        const similarAnimals = [
            {
                id: 'PAWS-2457',
                name: 'Max',
                breed: 'Labrador Retriever',
                age: '3 years',
                image: 'https://images.unsplash.com/photo-1552053831-71594a27632d?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80'
            },
            {
                id: 'PAWS-2458',
                name: 'Lucy',
                breed: 'Golden Retriever',
                age: '1 year',
                image: 'https://images.unsplash.com/photo-1560807707-8cc77767d783?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80'
            },
            {
                id: 'PAWS-2459',
                name: 'Charlie',
                breed: 'Beagle',
                age: '2 years',
                image: 'https://images.unsplash.com/photo-1505628346881-b72b27e84530?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80'
            },
            {
                id: 'PAWS-2460',
                name: 'Bella',
                breed: 'Labrador Mix',
                age: '4 years',
                image: 'https://images.unsplash.com/photo-1552053831-71594a27632d?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80'
            }
        ];
        
        const grid = document.querySelector('.animals-grid.mini-grid');
        
        similarAnimals.forEach(animal => {
            const card = document.createElement('div');
            card.className = 'animal-card';
            card.innerHTML = `
                <a href="animal_details.php?id=${animal.id}">
                    <div class="card-image">
                        <img src="${animal.image}" alt="${animal.name}">
                    </div>
                    <div class="card-content">
                        <h3>${animal.name}</h3>
                        <p>${animal.breed}, ${animal.age}</p>
                    </div>
                </a>
            `;
            grid.appendChild(card);
        });
    }
    </script>
</body>
</html>